import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'splash_screen.dart';
import 'onboarding_screen.dart';

import 'screen/auth/login_screen.dart';
import 'screen/auth/Registration_Screen.dart';
import 'screen/auth/select_role.dart';
import 'screen/auth/driver_reset_password.dart';

import 'screen/driver/driver_otp_screen.dart';
import 'screen/driver/driver_otp_screen_v2.dart';
import 'screen/driver/driver_otp_screen4.dart';
import 'screen/driver/driver_earnings_screen.dart';
import 'screen/driver/driver_otp_screen5.dart';
import 'screen/driver/driver_otp_screen7.dart';
import 'screen/driver/license_details_screen.dart';
import 'screen/driver/vehicle_details_screen.dart';
import 'screen/driver/driver_home_screen.dart';
import 'screen/driver/trip_assigned_screen.dart';
import 'screen/driver/trip_active_screen.dart';
import 'screen/driver/live_navigation_screen.dart';
import 'screen/driver/trips_screen.dart';
import 'screen/driver/available_trips_screen.dart';

import 'screen/trader/Trader_registration_screen.dart';
import 'screen/trader/TraderBusiness_Details_Screen.dart';
import 'screen/trader/TraderReviewConfirmScreen.dart';
import 'screen/trader/trader_home_screen.dart';
import 'screen/trader/trader_new_shipment_screen.dart';
import 'screen/trader/trader_otp_screen.dart';
import 'screen/trader/trader_rating_screen.dart';
import 'screen/trader/trader_rating_screen.dart';

import 'providers/user_provider.dart';
import 'providers/driver_provider.dart';
import 'providers/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => DriverProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TruckMate',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeProvider.isDark ? ThemeMode.dark : ThemeMode.light,
      initialRoute: '/splash',
      routes: {
        '/splash':                    (context) => const SplashScreen(),
        '/onboarding':                (context) => const OnboardingScreen(),
        '/select_role':               (context) => const SelectRole(),
        '/login':                     (context) => const LoginScreen(),
        '/signup':                    (context) => const RegistrationScreen(),
        '/driver_reset_password':     (context) => const DriverResetPassword(),
        '/driver_otp_v2':             (context) => const DriverOtpScreenV2(),
        '/driver_otp_basic':          (context) => const DriverOtpScreen(),
        '/driver_otp_4':              (context) => const DriverOtpScreen4(),
        '/driver_otp_5':              (context) => const DriverOTPScreen5(),
        '/driver_otp_7':              (context) => const DriverOTPScreen7(),
        '/license_details':           (context) => const LicenseDetailsScreen(),
        '/vehicle_details':           (context) => const VehicleDetailsScreen(),
        '/driver_home':               (context) => const DriverHomeScreen(),
        '/trip_assigned':             (context) => const TripAssignedScreen(),
        '/trip_active':               (context) => const TripActiveScreen(),
        '/live_navigation':           (context) => const LiveNavigationScreen(),
        '/trips':                     (context) => const TripsScreen(),
        '/available_trips':           (context) => const AvailableTripsScreen(),
        '/driver_earnings':           (context) => const DriverEarningsScreen(),
        '/driver_earnings_history':   (context) => const DriverEarningsHistoryScreen(),
        '/driver_earnings_breakdown': (context) => const DriverEarningsBreakdownScreen(),
        '/trader_registration':       (context) => const TraderRegistrationScreen(),
        '/trader_business_details':   (context) => const TraderBusinessDetailsScreen(),
        '/trader_review_confirm':     (context) => const TraderReviewConfirmScreen(),
        '/trader_home':               (context) => const TraderHomeScreen(),
        '/trader_new_shipment':       (context) => const TraderNewShipmentScreen(),
        '/trader_otp':                (context) => const TraderOtpScreen(),
        '/rate_driver':            (context) => const RateDriverScreen(),
        '/reviews_list':           (context) => const ReviewsListScreen(),
        '/rate_driver':           (context) => const RateDriverScreen(),
        '/write_review':          (context) => const WriteReviewScreen(),
        '/review_submitted':      (context) => const ReviewSubmittedScreen(),
        '/reviews_list':          (context) => const ReviewsListScreen(),
      },
    );
  }
}