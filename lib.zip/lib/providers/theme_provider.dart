import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ══════════════════════════════════════════════════════
//  APP THEME - كل الألوان في مكان واحد
// ══════════════════════════════════════════════════════
class AppTheme {
  final bool isDark;
  const AppTheme({required this.isDark});

  // ── Primary (ثابت في الاتنين) ──
  static const Color primary     = Color(0xFF00D5BE);
  static const Color primaryLight = Color(0xFF00F0D0);

  // ── Backgrounds ──
  Color get bg         => isDark ? const Color(0xFF0D1F2D) : const Color(0xFFF4F7FA);
  Color get bgDeep     => isDark ? const Color(0xFF0A1828) : const Color(0xFFFFFFFF);
  Color get card       => isDark ? const Color(0xFF152232) : const Color(0xFFFFFFFF);
  Color get cardDeep   => isDark ? const Color(0xFF0F1E2E) : const Color(0xFFF0F4F8);
  Color get fieldBg    => isDark ? const Color(0xFF112640) : const Color(0xFFF8FAFB);
  Color get border     => isDark ? const Color(0xFF1A3550) : const Color(0xFFDDE4EC);

  // ── Text ──
  Color get textPrimary => isDark ? const Color(0xFFE8F0F8) : const Color(0xFF1A2A3A);
  Color get textMuted   => isDark ? const Color(0xFF5F7E97) : const Color(0xFF7A95AA);
  Color get textSub     => isDark ? const Color(0xFF4A6572) : const Color(0xFF9BAAB8);

  // ── Specific ──
  Color get loginBg    => isDark ? const Color(0xFF0B1E2D) : const Color(0xFFFFFFFF);
  Color get selectBg   => isDark ? const Color(0xFF0F2334) : const Color(0xFFF4F7FA);
  Color get regBg      => isDark ? const Color(0xFF001A2C) : const Color(0xFFF4F7FA);
  Color get mapCard    => isDark ? const Color(0xFF0A1628) : const Color(0xFFE8F5F3);

  // ── Shadows ──
  List<BoxShadow> get cardShadow => isDark
      ? [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12)]
      : [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 4))];

  // ── Flutter ThemeData ──
  ThemeData get themeData => isDark ? darkTheme : lightTheme;

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: primary,
    scaffoldBackgroundColor: const Color(0xFF0D1F2D),
    colorScheme: const ColorScheme.dark(primary: primary),
  );

  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: primary,
    scaffoldBackgroundColor: const Color(0xFFF4F7FA),
    colorScheme: const ColorScheme.light(primary: primary),
  );
}

// ══════════════════════════════════════════════════════
//  THEME PROVIDER
// ══════════════════════════════════════════════════════
class ThemeProvider extends ChangeNotifier {
  bool _isDark = true;

  bool get isDark => _isDark;
  AppTheme get theme => AppTheme(isDark: _isDark);

  ThemeProvider() {
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    _isDark = prefs.getBool('isDarkMode') ?? true;
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDark = !_isDark;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', _isDark);
  }
}