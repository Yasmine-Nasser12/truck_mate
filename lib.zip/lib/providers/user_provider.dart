import 'package:flutter/material.dart';

class UserProvider with ChangeNotifier {
  String fullName = '';
  String phone = '';
  String email = '';
  String nationalId = '';
  String licenseNumber = '';
  String licenseType = '';
  String plateNumber = '';
  String truckType = '';
  String capacity = '';

  void update({
    String? fullName,
    String? phone,
    String? email,
    String? nationalId,
    String? licenseNumber,
    String? licenseType,
    String? plateNumber,
    String? truckType,
    String? capacity,
  }) {
    this.fullName      = fullName      ?? this.fullName;
    this.phone         = phone         ?? this.phone;
    this.email         = email         ?? this.email;
    this.nationalId    = nationalId    ?? this.nationalId;
    this.licenseNumber = licenseNumber ?? this.licenseNumber;
    this.licenseType   = licenseType   ?? this.licenseType;
    this.plateNumber   = plateNumber   ?? this.plateNumber;
    this.truckType     = truckType     ?? this.truckType;
    this.capacity      = capacity      ?? this.capacity;
    notifyListeners();
  }
}