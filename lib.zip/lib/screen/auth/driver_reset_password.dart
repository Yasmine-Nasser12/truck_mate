import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DriverResetPassword(),
    ),
  );
}

class DriverResetPassword extends StatefulWidget {
  const DriverResetPassword({super.key});

  @override
  State<DriverResetPassword> createState() => _DriverResetPasswordState();
}

class _DriverResetPasswordState extends State<DriverResetPassword> {
  bool _showPassword1 = false;
  bool _showPassword2 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF192C3D),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: SizedBox(
              width: 375,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 40),

                    const Text(
                      'Reset Password',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.w700,
                      ),
                    ),

                    const SizedBox(height: 10),

                    Container(
                      width: 120,
                      height: 0.8,
                      color: Colors.white.withValues(alpha: 0.2),
                    ),

                    const SizedBox(height: 14),

                    Text(
                      'Create your new password below',
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.4),
                        fontSize: 14,
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ===== الأيقونة =====
                    SizedBox(
                      width: 160,
                      height: 160,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CustomPaint(
                            size: const Size(140, 140),
                            painter: _DashedCirclePainter(),
                          ),
                          Container(
                            width: 110,
                            height: 110,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(
                                0xFF00D5BE,
                              ).withValues(alpha: 0.04),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFF00D5BE,
                                  ).withValues(alpha: 0.35),
                                  blurRadius: 40,
                                  spreadRadius: 8,
                                ),
                              ],
                            ),
                          ),
                          Icon(
                            Icons.shield_outlined,
                            color: const Color(
                              0xFF00D5BE,
                            ).withValues(alpha: 0.9),
                            size: 90,
                            shadows: [
                              Shadow(
                                color: const Color(
                                  0xFF00D5BE,
                                ).withValues(alpha: 0.8),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Icon(
                              Icons.check,
                              color: const Color(
                                0xFF00D5BE,
                              ).withValues(alpha: 0.9),
                              size: 28,
                              shadows: [
                                Shadow(
                                  color: const Color(
                                    0xFF00D5BE,
                                  ).withValues(alpha: 0.8),
                                  blurRadius: 15,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),

                    // ===== حقل New Password =====
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 343,
                          height: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xFF0D1E2E),
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                              color: const Color(
                                0xFF00D5BE,
                              ).withValues(alpha: 0.5),
                              width: 1.6,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(
                                  0xFF00D5BE,
                                ).withValues(alpha: 0.08),
                                blurRadius: 10,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: TextField(
                            obscureText: !_showPassword1,
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.6),
                              fontSize: 14,
                            ),
                            decoration: InputDecoration(
                              hintText: 'Enter new password',
                              hintStyle: TextStyle(
                                color: Colors.white.withValues(alpha: 0.25),
                                fontSize: 14,
                              ),
                              contentPadding: const EdgeInsets.only(
                                left: 20,
                                right: 0,
                                top: 14,
                                bottom: 0,
                              ),
                              border: InputBorder.none,
                              suffixIcon: IconButton(
                                icon: const Icon(
                                  Icons.visibility_outlined,
                                  color: Color(0xFF00D5BE),
                                  size: 20,
                                ),
                                onPressed: () => setState(
                                  () => _showPassword1 = !_showPassword1,
                                ),
                              ),
                            ),
                          ),
                        ),
                        // لابيل على الخط
                        Positioned(
                          top: -10,
                          left: 20,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            color: const Color(0xFF192C3D),
                            child: Text(
                              'New Password',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.4),
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // ===== حقل Rewrite =====
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 343,
                          height: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xFF0D1E2E),
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                              color: const Color(
                                0xFF00D5BE,
                              ).withValues(alpha: 0.5),
                              width: 1.6,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(
                                  0xFF00D5BE,
                                ).withValues(alpha: 0.08),
                                blurRadius: 10,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: TextField(
                            obscureText: !_showPassword2,
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.6),
                              fontSize: 14,
                            ),
                            decoration: InputDecoration(
                              hintText: 'Confirm new password',
                              hintStyle: TextStyle(
                                color: Colors.white.withValues(alpha: 0.25),
                                fontSize: 14,
                              ),
                              contentPadding: const EdgeInsets.only(
                                left: 20,
                                right: 0,
                                top: 14,
                                bottom: 0,
                              ),
                              border: InputBorder.none,
                              suffixIcon: IconButton(
                                icon: const Icon(
                                  Icons.visibility_outlined,
                                  color: Color(0xFF00D5BE),
                                  size: 20,
                                ),
                                onPressed: () => setState(
                                  () => _showPassword2 = !_showPassword2,
                                ),
                              ),
                            ),
                          ),
                        ),
                        // لابيل على الخط
                        Positioned(
                          top: -10,
                          left: 20,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            color: const Color(0xFF192C3D),
                            child: Text(
                              'Rewrite New Password',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.4),
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // ===== بوكس المتطلبات =====
                    Container(
                      width: 343,
                      height: 134.6,
                      padding: const EdgeInsets.fromLTRB(16.8, 16.8, 16.8, 0.8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0D1E2E),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.1),
                          width: 0.8,
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: Colors.white.withValues(alpha: 0.35),
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Password must include:',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.45),
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                _requirement('Minimum 8 characters'),
                                _requirement('At least 1 uppercase letter'),
                                _requirement('At least 1 number'),
                                _requirement(
                                  'At least 1 special character (!@#\$%)',
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // ===== زرار Reset Password =====
                    Container(
                      width: 343,
                      height: 52,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF009689),
                            Color(0xFF00BBA7),
                            Color(0xFF00B8DB),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF00D5BE,
                            ).withValues(alpha: 0.3),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          'Reset Password',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _requirement(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        children: [
          Text(
            '• ',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.35),
              fontSize: 13,
            ),
          ),
          Text(
            text,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.35),
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _DashedCirclePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF00D5BE).withValues(alpha: 0.4)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    const dashWidth = 6.0;
    const dashSpace = 8.0;
    final radius = size.width / 2;
    final center = Offset(size.width / 2, size.height / 2);
    final circumference = 2 * 3.14159 * radius;
    final dashCount = circumference / (dashWidth + dashSpace);
    final anglePerDash = 2 * 3.14159 / dashCount;

    for (int i = 0; i < dashCount.floor(); i++) {
      final startAngle = i * anglePerDash;
      final endAngle =
          startAngle + (anglePerDash * dashWidth / (dashWidth + dashSpace));
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        endAngle - startAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
