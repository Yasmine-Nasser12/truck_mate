import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import '/screen/driver/trip_assigned_screen.dart';
import '/screen/driver/trips_screen.dart';
import '/screen/driver/available_trips_screen.dart';
import '/providers/user_provider.dart';
import '/providers/driver_provider.dart';

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.15).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _toggleOnline() => context.read<DriverProvider>().toggleOnline();

  @override
  Widget build(BuildContext context) {
    final isOnline = context.watch<DriverProvider>().isOnline;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {},
      child: Scaffold(
        backgroundColor: const Color(0xFF0D1F2D),
        body: SafeArea(
          child: isOnline ? _buildOnline() : _buildOffline(),
        ),
      ),
    );
  }

  Widget _buildOffline() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          _buildHeader(isOnline: false),
          const SizedBox(height: 16),
          _buildBadge('No Active Trip', Colors.white24),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
            decoration: BoxDecoration(
              color: const Color(0xFF152232),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.08),
                  ),
                  child: Icon(Icons.local_shipping_outlined,
                      color: Colors.white.withOpacity(0.35), size: 36),
                ),
                const SizedBox(height: 20),
                const Text("You're Offline",
                    style: TextStyle(color: Colors.white, fontSize: 22,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text("You're not receiving new trips",
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.45), fontSize: 14)),
                const SizedBox(height: 28),
                _GradientButton(text: 'Go Online', onTap: _toggleOnline),
              ],
            ),
          ),
          const SizedBox(height: 32),
          _buildRecentTripsHeader(),
          const SizedBox(height: 14),
          Builder(builder: (ctx) {
            final trips = ctx.watch<DriverProvider>().recentTrips.take(2).toList();
            if (trips.isEmpty) return const SizedBox.shrink();
            return Column(children: [
              for (int i = 0; i < trips.length; i++) ...[
                if (i > 0) const SizedBox(height: 10),
                _buildTripCard(
                  id: trips[i].id,
                  date: trips[i].date,
                  route: '${trips[i].origin} → ${trips[i].destination}',
                  status: 'Completed',
                  time: trips[i].time,
                ),
              ],
            ]);
          }),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildOnline() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          _buildHeader(isOnline: true),
          const SizedBox(height: 16),
          _buildBadge('No Active Trip', Colors.white24),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFF0D3D30), Color(0xFF0D2A35)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: const Color(0xFF00D5BE).withOpacity(0.2), width: 1),
            ),
            child: Column(
              children: [
                AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, __) => Transform.scale(
                    scale: _pulseAnim.value,
                    child: Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF00D5BE),
                        boxShadow: [BoxShadow(
                            color: const Color(0xFF00D5BE).withOpacity(0.5),
                            blurRadius: 24, spreadRadius: 4)],
                      ),
                      child: const Icon(Icons.wifi_tethering,
                          color: Colors.white, size: 34),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Text("You're Online",
                    style: TextStyle(color: Colors.white, fontSize: 22,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text('Waiting for new trip requests',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.55), fontSize: 14)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                      color: Colors.black26,
                      borderRadius: BorderRadius.circular(20)),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.location_on_outlined,
                          color: Color(0xFF00D5BE), size: 16),
                      SizedBox(width: 6),
                      Text('Zone: Downtown Area',
                          style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _OutlineButton(text: 'Go Offline', onTap: _toggleOnline),
          const SizedBox(height: 28),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Incoming Trips',
                  style: TextStyle(color: Colors.white, fontSize: 18,
                      fontWeight: FontWeight.w700)),
              GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(
                        builder: (_) => const TripAssignedScreen())),
                child: const Text('Show Offer',
                    style: TextStyle(color: Color(0xFF00D5BE), fontSize: 14)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32),
            decoration: BoxDecoration(
                color: const Color(0xFF152232),
                borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF00D5BE).withOpacity(0.12),
                      ),
                      child: const Icon(Icons.inbox_outlined,
                          color: Color(0xFF00D5BE), size: 28),
                    ),
                    Positioned(
                      top: -4, right: -4,
                      child: Container(
                        width: 18, height: 18,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF00D5BE)),
                        child: const Icon(Icons.south_west,
                            color: Colors.white, size: 11),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Text('No trips available right now',
                    style: TextStyle(color: Colors.white, fontSize: 15)),
                const SizedBox(height: 6),
                Text('Stay online to receive nearby shipments',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4), fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 28),
          const Text('Today',
              style: TextStyle(color: Colors.white, fontSize: 18,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 14),
          Builder(builder: (ctx) {
            final stats = ctx.watch<DriverProvider>().todayStats;
            return Column(children: [
              _buildStatRow(icon: Icons.trending_up,
                  iconColor: const Color(0xFFF59E0B),
                  label: 'Trips completed',
                  value: stats.tripsCompleted.toString()),
              const SizedBox(height: 10),
              _buildStatRow(icon: Icons.attach_money,
                  iconColor: const Color(0xFF00D5BE),
                  label: 'Earnings',
                  value: '${stats.earnings.toStringAsFixed(1)} EGP',
                  valueBold: true),
              const SizedBox(height: 10),
              _buildStatRow(icon: Icons.access_time,
                  iconColor: const Color(0xFFF59E0B),
                  label: 'Online time',
                  value: stats.onlineTime, valueBold: true),
            ]);
          }),
          const SizedBox(height: 28),
          _buildRecentTripsHeader(),
          const SizedBox(height: 14),
          _buildTripCard(id: 'SHP-4519', date: 'Jan 30, 2026',
              route: 'Nasr City Hub → Heliopolis Plaza',
              status: 'Completed', time: '2:30 PM'),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ── Logout ──
  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF152232),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Logout', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text('Are you sure you want to logout?', style: TextStyle(color: Color(0xFF6B8A9E))),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF6B8A9E))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Logout', style: TextStyle(color: Color(0xFF00D5BE), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', false);
      await prefs.remove('role');
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  // ── Header - الاسم من Provider ──
  Widget _buildHeader({bool isOnline = false}) {
    // بنجيب الاسم من Provider - لو فاضي بنحط fallback
    final user = context.watch<UserProvider>();
    final displayName = user.fullName.isNotEmpty ? user.fullName : 'Driver';

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome back',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 13)),
              const SizedBox(height: 2),
              Text(displayName,
                  style: const TextStyle(color: Colors.white, fontSize: 22,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Container(width: 60, height: 2,
                  decoration: BoxDecoration(
                      color: const Color(0xFF00D5BE),
                      borderRadius: BorderRadius.circular(2))),
            ],
          ),
        ),
        _pill(child: const Row(children: [
          Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
          SizedBox(width: 4),
          Text('4.8', style: TextStyle(color: Colors.white, fontSize: 13)),
        ])),
        const SizedBox(width: 8),
        _pill(child: Row(children: [
          Container(width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isOnline ? const Color(0xFF00D5BE) : Colors.white38,
              )),
          const SizedBox(width: 6),
          Text(isOnline ? 'ONLINE' : 'OFFLINE',
              style: TextStyle(
                  color: isOnline
                      ? const Color(0xFF00D5BE) : Colors.white60,
                  fontSize: 12, fontWeight: FontWeight.w600)),
        ])),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _logout,
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF1A0A0A),
              border: Border.all(color: const Color(0xFFFF476D).withOpacity(0.4)),
            ),
            child: const Icon(Icons.logout, color: Color(0xFFFF476D), size: 20),
          ),
        ),
      ],
    );
  }

  Widget _pill({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
            color: const Color(0xFF1E3040),
            borderRadius: BorderRadius.circular(20)),
        child: child,
      );

  Widget _buildBadge(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(20)),
        child: Text(text,
            style: const TextStyle(color: Colors.white70, fontSize: 13)),
      );

  Widget _buildStatRow({required IconData icon, required Color iconColor,
      required String label, required String value, bool valueBold = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
          color: const Color(0xFF152232),
          borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(icon, color: iconColor, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.55), fontSize: 14))),
          Text(value, style: TextStyle(
              color: Colors.white,
              fontSize: valueBold ? 18 : 16,
              fontWeight: valueBold ? FontWeight.w700 : FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildRecentTripsHeader() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Recent Trips',
              style: TextStyle(color: Colors.white, fontSize: 18,
                  fontWeight: FontWeight.w700)),
          GestureDetector(
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const TripsScreen())),
            child: const Text('View all',
                style: TextStyle(color: Color(0xFF00D5BE), fontSize: 14)),
          ),
        ],
      );

  Widget _buildTripCard({required String id, required String date,
      required String route, required String status, required String time}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFF152232),
          borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(id, style: TextStyle(
                  color: Colors.white.withOpacity(0.45), fontSize: 12)),
              Text(date, style: TextStyle(
                  color: Colors.white.withOpacity(0.45), fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          Text(route, style: const TextStyle(color: Colors.white,
              fontSize: 15, fontWeight: FontWeight.w500)),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF00D5BE).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(children: [
                  Container(width: 7, height: 7,
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: Color(0xFF00D5BE))),
                  const SizedBox(width: 5),
                  Text(status, style: const TextStyle(
                      color: Color(0xFF00D5BE), fontSize: 12)),
                ]),
              ),
              Text(time, style: TextStyle(
                  color: Colors.white.withOpacity(0.45), fontSize: 13)),
            ],
          ),
        ],
      ),
    );
  }
}

class _GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _GradientButton({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity, height: 52,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Color(0xFF00D5BE), Color(0xFF00B4A0)]),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(
                color: const Color(0xFF00D5BE).withOpacity(0.35),
                blurRadius: 16, offset: const Offset(0, 6))],
          ),
          alignment: Alignment.center,
          child: Text(text, style: const TextStyle(
              color: Colors.white, fontSize: 16,
              fontWeight: FontWeight.w700)),
        ),
      );
}

class _OutlineButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _OutlineButton({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity, height: 52,
          decoration: BoxDecoration(
            color: const Color(0xFF1E3040),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white12),
          ),
          alignment: Alignment.center,
          child: Text(text, style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 16, fontWeight: FontWeight.w500)),
        ),
      );
}