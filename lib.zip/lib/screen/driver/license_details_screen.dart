﻿import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/theme_provider.dart';
import '/screen/driver/vehicle_details_screen.dart';

class LicenseDetailsScreen extends StatefulWidget {
  final String fullName;
  final String phone;
  final String email;
  final String nationalId;

  const LicenseDetailsScreen({
    super.key,
    this.fullName = '',
    this.phone = '',
    this.email = '',
    this.nationalId = '',
  });

  @override
  State<LicenseDetailsScreen> createState() => _LicenseDetailsScreenState();
}

class _LicenseDetailsScreenState extends State<LicenseDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _licenseNumberController = TextEditingController();
  final TextEditingController _licenseTypeController = TextEditingController();

  String? _uploadedFileName;
  bool _showFileError = false;

  @override
  void dispose() {
    _licenseNumberController.dispose();
    _licenseTypeController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.isNotEmpty) {
      setState(() {
        _uploadedFileName = result.files.first.name;
        _showFileError = false;
      });
    }
  }

  void _navigateToVehicleDetails() {
    final isFormValid = _formKey.currentState!.validate();
    final hasFile = _uploadedFileName != null;
    if (!hasFile) setState(() => _showFileError = true);
    if (!isFormValid || !hasFile) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VehicleDetailsScreen(
          fullName: widget.fullName,
          phone: widget.phone,
          email: widget.email,
          nationalId: widget.nationalId,
          licenseNumber: _licenseNumberController.text,
          licenseType: _licenseTypeController.text,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<ThemeProvider>().theme;
    return Scaffold(
      backgroundColor: t.regBg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: t.isDark ? Colors.white.withOpacity(0.02) : Colors.transparent,
                borderRadius: BorderRadius.circular(45),
                border: Border.all(
                  color: t.isDark ? Colors.white.withOpacity(0.08) : t.border,
                  width: 1.2,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            width: 45,
                            height: 45,
                            decoration: BoxDecoration(
                              color: const Color(0xFF132D3E).withOpacity(0.6),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.arrow_back,
                                color: Color(0xFF00D1D1), size: 22),
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text('Create Account',
                          style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white)),
                      const SizedBox(height: 8),
                      Text('Driver Registration',
                          style: TextStyle(
                              fontSize: 16, color: t.textMuted)),
                      const SizedBox(height: 40),
                      const DriverStepIndicator(currentStep: 2),
                      const SizedBox(height: 40),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 25),
                        decoration: BoxDecoration(
                          color: t.card,
                          borderRadius: BorderRadius.circular(35),
                          border: Border.all(
                            color: const Color(0xFF00D1D1).withOpacity(0.1),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Center(
                              child: Text('License Details',
                                  style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(height: 30),
                            DriverInputField(
                              label: 'License Number',
                              hint: 'Enter license number',
                              icon: Icons.description_outlined,
                              controller: _licenseNumberController,
                              validator: (v) =>
                                  (v == null || v.trim().isEmpty)
                                      ? 'Please enter license number'
                                      : null,
                            ),
                            DriverInputField(
                              label: 'License Type',
                              hint: 'e.g., Commercial Class A',
                              icon: Icons.workspace_premium_outlined,
                              controller: _licenseTypeController,
                              validator: (v) =>
                                  (v == null || v.trim().isEmpty)
                                      ? 'Please enter license type'
                                      : null,
                            ),
                            const Text('Upload License',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500)),
                            const SizedBox(height: 10),
                            DriverUploadField(
                              fileName: _uploadedFileName ?? 'Choose file...',
                              showError: _showFileError,
                              onTap: _pickFile,
                            ),
                            const SizedBox(height: 30),
                            _buildNextButton(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text('© 2025 TruckMate',
                          style: TextStyle(
                              color: Color(0xFF6B8A9E), fontSize: 14)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNextButton() {
    return Container(
      width: double.infinity,
      height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [Color(0xFF009EA3), Color(0xFF00D1D1)]),
        borderRadius: BorderRadius.circular(16),
      ),
      child: ElevatedButton(
        onPressed: _navigateToVehicleDetails,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        child: const Text('Next',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white)),
      ),
    );
  }
}

// ========== Shared Widgets (used by both screens) ==========

class DriverStepIndicator extends StatelessWidget {
  final int currentStep;
  const DriverStepIndicator({super.key, required this.currentStep});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _step(Icons.person, currentStep >= 1),
        _line(currentStep >= 2),
        _step(Icons.badge_outlined, currentStep >= 2),
        _line(currentStep >= 3),
        _step(Icons.local_shipping, currentStep >= 3),
      ],
    );
  }

  Widget _step(IconData icon, bool active) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active ? Colors.transparent : const Color(0xFF132D3E),
          border: Border.all(
            color: active ? const Color(0xFF00D1D1) : Colors.transparent,
            width: 1.5,
          ),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: const Color(0xFF00D1D1).withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  )
                ]
              : null,
        ),
        child: Icon(icon,
            color: active
                ? const Color(0xFF00D1D1)
                : const Color(0xFF6B8A9E),
            size: 26),
      );

  Widget _line(bool active) => Container(
        width: 45,
        height: 2,
        color: active ? const Color(0xFF00D1D1) : const Color(0xFF132D3E),
      );
}

class DriverInputField extends StatelessWidget {
  final String label, hint;
  final IconData icon;
  final TextEditingController controller;
  final String? Function(String?)? validator;

  const DriverInputField({
    super.key,
    required this.label,
    required this.hint,
    required this.icon,
    required this.controller,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w500)),
          const SizedBox(height: 10),
          TextFormField(
            controller: controller,
            validator: validator,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle:
                  const TextStyle(color: Color(0xFF6B8A9E), fontSize: 14),
              prefixIcon:
                  Icon(icon, color: const Color(0xFF00D1D1), size: 22),
              filled: true,
              fillColor: const Color(0xFF001A2C).withOpacity(0.6),
              errorStyle: const TextStyle(color: Colors.redAccent),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.05)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    const BorderSide(color: Color(0xFF00D1D1), width: 1),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    const BorderSide(color: Colors.redAccent, width: 1),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    const BorderSide(color: Colors.redAccent, width: 1.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DriverUploadField extends StatelessWidget {
  final String fileName;
  final bool showError;
  final VoidCallback onTap;

  const DriverUploadField({
    super.key,
    required this.fileName,
    required this.showError,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            width: double.infinity,
            height: 58,
            decoration: BoxDecoration(
              color: const Color(0xFF001A2C).withOpacity(0.6),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: showError
                    ? Colors.redAccent
                    : Colors.white.withOpacity(0.05),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.upload_outlined,
                    color: Color(0xFF00D1D1), size: 22),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(fileName,
                      style: const TextStyle(
                          color: Color(0xFF6B8A9E), fontSize: 14),
                      overflow: TextOverflow.ellipsis),
                ),
              ],
            ),
          ),
        ),
        if (showError)
          const Padding(
            padding: EdgeInsets.only(top: 8, left: 12),
            child: Text('Please upload license file',
                style: TextStyle(color: Colors.redAccent, fontSize: 12)),
          ),
      ],
    );
  }
}