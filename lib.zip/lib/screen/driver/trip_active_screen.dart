import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/user_provider.dart';
import '/providers/driver_provider.dart';
import '/screen/driver/live_navigation_screen.dart';
import '/screen/driver/driver_home_screen.dart';

class TripActiveScreen extends StatefulWidget {
  const TripActiveScreen({super.key});

  @override
  State<TripActiveScreen> createState() => _TripActiveScreenState();
}

class _TripActiveScreenState extends State<TripActiveScreen>
    with SingleTickerProviderStateMixin {

  late AnimationController _progressCtrl;
  late Animation<double>   _progressAnim;
  final double _progress = 0.65;

  @override
  void initState() {
    super.initState();
    _progressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _progressAnim = Tween<double>(begin: 0.0, end: _progress).animate(
      CurvedAnimation(parent: _progressCtrl, curve: Curves.easeOutCubic),
    );
    _progressCtrl.forward();
  }

  @override
  void dispose() {
    _progressCtrl.dispose();
    super.dispose();
  }

  void _showCompleteDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black54,
      builder: (_) => _CompleteTripDialog(
        onConfirm: () {
          context.read<DriverProvider>().completeTrip();
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const DriverHomeScreen()),
            (route) => false,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ✅ الاسم من Provider
    final user = context.watch<UserProvider>();
    final displayName = user.fullName.isNotEmpty ? user.fullName : 'Driver';

    return Scaffold(
      backgroundColor: const Color(0xFF0D1F2D),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _buildHeader(displayName),
              const SizedBox(height: 16),
              _buildBadge('In Transit', const Color(0xFF00D5BE)),
              const SizedBox(height: 24),

              // Trip Card
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF152232),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: const Color(0xFF00D5BE).withOpacity(0.15)),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text('SHP-4521',
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 13)),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Route
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(children: [
                            Container(width: 12, height: 12,
                                decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFFF59E0B))),
                            Container(width: 2, height: 40,
                                color: const Color(0xFF00D5BE).withOpacity(0.3)),
                            Container(
                              width: 12, height: 12,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: const Color(0xFF00D5BE), width: 2),
                              ),
                              child: Center(child: Container(
                                width: 5, height: 5,
                                decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFF00D5BE)),
                              )),
                            ),
                          ]),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('From', style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 12)),
                                const SizedBox(height: 2),
                                Text(context.watch<DriverProvider>().activeTrip?.origin ?? 'Maadi Distribution Center, Cairo',
                                    style: TextStyle(color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600)),
                                const SizedBox(height: 16),
                                Text('To', style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 12)),
                                const SizedBox(height: 2),
                                Text(context.watch<DriverProvider>().activeTrip?.destination ?? 'New Cairo Tech Hub, Cairo',
                                    style: TextStyle(color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // ETA + Progress
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          Expanded(child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                                color: const Color(0xFF0D1F2D),
                                borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('ETA', style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 12)),
                                const SizedBox(height: 6),
                                const Text('45 min', style: TextStyle(
                                    color: Color(0xFF00D5BE), fontSize: 22,
                                    fontWeight: FontWeight.w800)),
                              ],
                            ),
                          )),
                          const SizedBox(width: 12),
                          Expanded(child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                                color: const Color(0xFF0D1F2D),
                                borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Progress', style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 12)),
                                const SizedBox(height: 6),
                                const Text('65%', style: TextStyle(
                                    color: Color(0xFF00D5BE), fontSize: 22,
                                    fontWeight: FontWeight.w800)),
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Progress Bar
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: AnimatedBuilder(
                        animation: _progressAnim,
                        builder: (_, __) => ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: _progressAnim.value,
                            minHeight: 7,
                            backgroundColor:
                                const Color(0xFF00D5BE).withOpacity(0.12),
                            valueColor: const AlwaysStoppedAnimation<Color>(
                                Color(0xFF00D5BE)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // View Live Navigation
              GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(
                        builder: (_) => const LiveNavigationScreen())),
                child: Container(
                  width: double.infinity, height: 54,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [Color(0xFF00D5BE), Color(0xFF00B4A0)]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(
                        color: const Color(0xFF00D5BE).withOpacity(0.35),
                        blurRadius: 16, offset: const Offset(0, 6))],
                  ),
                  alignment: Alignment.center,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.navigation, color: Colors.white, size: 20),
                      SizedBox(width: 10),
                      Text('View Live Navigation',
                          style: TextStyle(color: Colors.white,
                              fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Shipment Details
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    color: const Color(0xFF152232),
                    borderRadius: BorderRadius.circular(16)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Shipment Details',
                        style: TextStyle(color: Colors.white, fontSize: 16,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(height: 16),
                    _infoRow('Client', 'El-Ezz Steel'),
                    const SizedBox(height: 12),
                    _infoRow('Cargo', 'Electronics – Fragile'),
                    const SizedBox(height: 14),
                    Row(children: [
                      _fragileTag(),
                      const SizedBox(width: 10),
                      _weightTag('2,400 lbs'),
                    ]),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // End Trip
              GestureDetector(
                onTap: _showCompleteDialog,
                child: Container(
                  width: double.infinity, height: 54,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(
                        color: const Color(0xFFEF4444).withOpacity(0.35),
                        blurRadius: 16, offset: const Offset(0, 6))],
                  ),
                  alignment: Alignment.center,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.flag_outlined, color: Colors.white, size: 20),
                      SizedBox(width: 8),
                      Text('End Trip',
                          style: TextStyle(color: Colors.white,
                              fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),
              Row(children: [
                Container(width: 8, height: 8,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white24)),
                const SizedBox(width: 8),
                Text('Offline – Not receiving new trips after completion',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.35), fontSize: 12)),
              ]),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(String displayName) {
    return Row(
      children: [
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Welcome back', style: TextStyle(
                color: Colors.white.withOpacity(0.5), fontSize: 13)),
            const SizedBox(height: 2),
            Text(displayName, style: const TextStyle(
                color: Colors.white, fontSize: 22,
                fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Container(width: 60, height: 2,
                decoration: BoxDecoration(color: const Color(0xFF00D5BE),
                    borderRadius: BorderRadius.circular(2))),
          ],
        )),
        _pill(child: const Row(children: [
          Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
          SizedBox(width: 4),
          Text('4.8', style: TextStyle(color: Colors.white, fontSize: 13)),
        ])),
        const SizedBox(width: 8),
        _pill(child: Row(children: [
          Container(width: 8, height: 8,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: Colors.white38)),
          const SizedBox(width: 6),
          const Text('OFFLINE', style: TextStyle(color: Colors.white60,
              fontSize: 12, fontWeight: FontWeight.w600)),
        ])),
        const SizedBox(width: 8),
        Container(width: 38, height: 38,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: Color(0xFF1E3040)),
            child: Icon(Icons.person_outline,
                color: Colors.white.withOpacity(0.7), size: 22)),
      ],
    );
  }

  Widget _pill({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: const Color(0xFF1E3040),
            borderRadius: BorderRadius.circular(20)),
        child: child,
      );

  Widget _buildBadge(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.4), width: 1),
        ),
        child: Text(text, style: TextStyle(color: color, fontSize: 13,
            fontWeight: FontWeight.w600)),
      );

  Widget _infoRow(String label, String value) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(
              color: Colors.white.withOpacity(0.45), fontSize: 14)),
          Text(value, style: const TextStyle(color: Colors.white,
              fontSize: 14, fontWeight: FontWeight.w600)),
        ],
      );

  Widget _fragileTag() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: const Color(0xFFF59E0B).withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
              color: const Color(0xFFF59E0B).withOpacity(0.4), width: 1),
        ),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.warning_amber_rounded, color: Color(0xFFF59E0B), size: 13),
          SizedBox(width: 5),
          Text('FRAGILE', style: TextStyle(color: Color(0xFFF59E0B),
              fontSize: 11, fontWeight: FontWeight.w700)),
        ]),
      );

  Widget _weightTag(String w) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(w, style: TextStyle(
            color: Colors.white.withOpacity(0.6), fontSize: 12)),
      );
}

class _CompleteTripDialog extends StatelessWidget {
  final VoidCallback onConfirm;
  const _CompleteTripDialog({required this.onConfirm});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
            color: const Color(0xFF152232),
            borderRadius: BorderRadius.circular(24)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFEF4444).withOpacity(0.9)),
              child: const Icon(Icons.error_outline,
                  color: Colors.white, size: 34),
            ),
            const SizedBox(height: 20),
            const Text('Complete Trip?',
                style: TextStyle(color: Colors.white, fontSize: 22,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text(
              'Confirm that you have successfully delivered the shipment to New Cairo Tech Hub.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white.withOpacity(0.55),
                  fontSize: 14, height: 1.5),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
                onConfirm();
              },
              child: Container(
                width: double.infinity, height: 52,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Color(0xFF00D5BE), Color(0xFF00B4A0)]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(
                      color: const Color(0xFF00D5BE).withOpacity(0.4),
                      blurRadius: 14, offset: const Offset(0, 4))],
                ),
                alignment: Alignment.center,
                child: const Text('Yes, Complete Trip',
                    style: TextStyle(color: Colors.white, fontSize: 16,
                        fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: double.infinity, height: 52,
                decoration: BoxDecoration(
                    color: const Color(0xFF1E3040),
                    borderRadius: BorderRadius.circular(14)),
                alignment: Alignment.center,
                child: Text('Cancel',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.65), fontSize: 15)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}