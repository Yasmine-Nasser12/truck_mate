﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/theme_provider.dart';
import 'package:provider/provider.dart';
import '/screen/driver/driver_otp_screen4.dart';
import '/providers/user_provider.dart';

class VehicleDetailsScreen extends StatefulWidget {
  final String fullName;
  final String phone;
  final String email;
  final String nationalId;
  final String licenseNumber;
  final String licenseType;

  const VehicleDetailsScreen({
    super.key,
    this.fullName = '',
    this.phone = '',
    this.email = '',
    this.nationalId = '',
    this.licenseNumber = '',
    this.licenseType = '',
  });

  @override
  State<VehicleDetailsScreen> createState() => _VehicleDetailsScreenState();
}

class _VehicleDetailsScreenState extends State<VehicleDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _plateController     = TextEditingController();
  final TextEditingController _truckTypeController = TextEditingController();
  final TextEditingController _capacityController  = TextEditingController();
  final TextEditingController _passwordController  = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirm  = true;
  String _capacityUnit  = 'kg'; // ← الوحدة الافتراضية

  @override
  void dispose() {
    _plateController.dispose();
    _truckTypeController.dispose();
    _capacityController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _handleNext() {
    if (!_formKey.currentState!.validate()) return;

    // حفظ البيانات في Provider
    final capacityWithUnit =
        '${_capacityController.text} $_capacityUnit';

    context.read<UserProvider>().update(
      fullName:      widget.fullName,
      phone:         widget.phone,
      email:         widget.email,
      nationalId:    widget.nationalId,
      licenseNumber: widget.licenseNumber,
      licenseType:   widget.licenseType,
      plateNumber:   _plateController.text,
      truckType:     _truckTypeController.text,
      capacity:      capacityWithUnit,
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DriverOtpScreen4(
          fullName:      widget.fullName,
          phone:         widget.phone,
          email:         widget.email,
          nationalId:    widget.nationalId,
          licenseNumber: widget.licenseNumber,
          licenseType:   widget.licenseType,
          plateNumber:   _plateController.text,
          truckType:     _truckTypeController.text,
          capacity:      capacityWithUnit,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<ThemeProvider>().theme;
    return Scaffold(
      backgroundColor: t.regBg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: t.isDark ? Colors.white.withOpacity(0.02) : Colors.transparent,
                borderRadius: BorderRadius.circular(45),
                border: Border.all(
                    color: t.isDark ? Colors.white.withOpacity(0.08) : t.border, width: 1.2),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            width: 45, height: 45,
                            decoration: BoxDecoration(
                              color: const Color(0xFF132D3E).withOpacity(0.6),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.arrow_back,
                                color: Color(0xFF00D1D1), size: 22),
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text('Create Account',
                          style: TextStyle(fontSize: 24,
                              fontWeight: FontWeight.bold, color: Colors.white)),
                      const SizedBox(height: 8),
                      Text('Driver Registration',
                          style: TextStyle(
                              fontSize: 16, color: t.textMuted)),
                      const SizedBox(height: 40),
                      const DriverStepIndicator(currentStep: 3),
                      const SizedBox(height: 40),

                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 25),
                        decoration: BoxDecoration(
                          color: t.card,
                          borderRadius: BorderRadius.circular(35),
                          border: Border.all(
                              color: const Color(0xFF00D1D1).withOpacity(0.1)),
                        ),
                        child: Column(
                          children: [
                            const Text('Vehicle Information',
                                style: TextStyle(fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 30),

                            DriverInputField(
                              label: 'Plate Number',
                              hint: 'e.g. أ ب ج 123',
                              icon: Icons.tag,
                              controller: _plateController,
                              validator: (v) => (v == null || v.trim().isEmpty)
                                  ? 'Please enter plate number' : null,
                            ),
                            DriverInputField(
                              label: 'Truck Type',
                              hint: 'e.g., Box Truck, Flatbed',
                              icon: Icons.local_shipping_outlined,
                              controller: _truckTypeController,
                              validator: (v) => (v == null || v.trim().isEmpty)
                                  ? 'Please enter truck type' : null,
                            ),

                            // ── Capacity مع وحدة ──
                            Padding(
                              padding: const EdgeInsets.only(bottom: 22),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Capacity',
                                      style: TextStyle(color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500)),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      // حقل الرقم
                                      Expanded(
                                        child: TextFormField(
                                          controller: _capacityController,
                                          keyboardType: TextInputType.number,
                                          style: const TextStyle(
                                              color: Colors.white, fontSize: 16),
                                          validator: (v) =>
                                              (v == null || v.trim().isEmpty)
                                                  ? 'Required' : null,
                                          decoration: InputDecoration(
                                            hintText: 'e.g. 5000',
                                            hintStyle: const TextStyle(
                                                color: Color(0xFF6B8A9E),
                                                fontSize: 14),
                                            prefixIcon: const Icon(
                                                Icons.inventory_2_outlined,
                                                color: Color(0xFF00D1D1),
                                                size: 22),
                                            filled: true,
                                            fillColor: const Color(0xFF001A2C)
                                                .withOpacity(0.6),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              borderSide: BorderSide(
                                                  color: Colors.white
                                                      .withOpacity(0.05)),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              borderSide: const BorderSide(
                                                  color: Color(0xFF00D1D1),
                                                  width: 1),
                                            ),
                                            errorBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              borderSide: const BorderSide(
                                                  color: Colors.redAccent),
                                            ),
                                            focusedErrorBorder:
                                                OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              borderSide: const BorderSide(
                                                  color: Colors.redAccent,
                                                  width: 1.5),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      // Dropdown الوحدة
                                      Container(
                                        height: 56,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF001A2C)
                                              .withOpacity(0.6),
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          border: Border.all(
                                              color: const Color(0xFF00D1D1)
                                                  .withOpacity(0.4)),
                                        ),
                                        child: DropdownButtonHideUnderline(
                                          child: DropdownButton<String>(
                                            value: _capacityUnit,
                                            dropdownColor:
                                                const Color(0xFF011624),
                                            style: const TextStyle(
                                                color: Color(0xFF00D1D1),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600),
                                            icon: const Icon(
                                                Icons.keyboard_arrow_down,
                                                color: Color(0xFF00D1D1),
                                                size: 18),
                                            items: const [
                                              DropdownMenuItem(
                                                  value: 'kg',
                                                  child: Text('kg')),
                                              DropdownMenuItem(
                                                  value: 'ton',
                                                  child: Text('ton')),
                                            ],
                                            onChanged: (v) => setState(
                                                () => _capacityUnit = v!),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            _PasswordField(
                              label: 'Password',
                              hint: 'Enter your password',
                              controller: _passwordController,
                              isObscured: _obscurePassword,
                              onToggle: () => setState(
                                  () => _obscurePassword = !_obscurePassword),
                              validator: (v) {
                                if (v == null || v.isEmpty)
                                  return 'Please enter password';
                                if (v.length < 8) return 'Min 8 characters';
                                return null;
                              },
                            ),
                            _PasswordField(
                              label: 'Confirm Password',
                              hint: 'Retype your password',
                              controller: _confirmPasswordController,
                              isObscured: _obscureConfirm,
                              onToggle: () => setState(
                                  () => _obscureConfirm = !_obscureConfirm),
                              validator: (v) {
                                if (v != _passwordController.text)
                                  return 'Passwords do not match';
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            _buildFinishButton(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text('© 2025 TruckMate',
                          style: TextStyle(
                              color: Color(0xFF6B8A9E), fontSize: 14)),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFinishButton() {
    return Container(
      width: double.infinity, height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [Color(0xFF009EA3), Color(0xFF00D1D1)]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
          color: const Color(0xFF00D1D1).withOpacity(0.3),
          blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: ElevatedButton(
        onPressed: _handleNext,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        child: const Text('Next',
            style: TextStyle(color: Colors.white,
                fontWeight: FontWeight.bold, fontSize: 18)),
      ),
    );
  }
}

// ── Step Indicator ──
class DriverStepIndicator extends StatelessWidget {
  final int currentStep;
  const DriverStepIndicator({super.key, required this.currentStep});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildStep(Icons.person, currentStep >= 1),
        _buildLine(currentStep >= 2),
        _buildStep(Icons.badge_outlined, currentStep >= 2),
        _buildLine(currentStep >= 3),
        _buildStep(Icons.local_shipping, currentStep >= 3),
      ],
    );
  }

  Widget _buildStep(IconData icon, bool isActive) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isActive ? Colors.transparent : const Color(0xFF132D3E),
          border: Border.all(
            color: isActive ? const Color(0xFF00D1D1) : Colors.transparent,
            width: 1.5,
          ),
        ),
        child: Icon(icon,
            color: isActive
                ? const Color(0xFF00D1D1) : const Color(0xFF6B8A9E),
            size: 26),
      );

  Widget _buildLine(bool isActive) => Container(
        width: 45, height: 1.2,
        color: isActive
            ? const Color(0xFF00D1D1) : const Color(0xFF132D3E),
      );
}

// ── Input Field ──
class DriverInputField extends StatelessWidget {
  final String label, hint;
  final IconData icon;
  final TextEditingController controller;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;

  const DriverInputField({
    super.key,
    required this.label,
    required this.hint,
    required this.icon,
    required this.controller,
    this.keyboardType,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white,
              fontSize: 15, fontWeight: FontWeight.w500)),
          const SizedBox(height: 10),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            validator: validator,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                  color: Color(0xFF6B8A9E), fontSize: 14),
              prefixIcon: Icon(icon,
                  color: const Color(0xFF00D1D1), size: 22),
              filled: true,
              fillColor: const Color(0xFF001A2C).withOpacity(0.6),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.05)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                    color: Color(0xFF00D1D1), width: 1),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                    color: Colors.redAccent, width: 1.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Password Field ──
class _PasswordField extends StatelessWidget {
  final String label, hint;
  final TextEditingController controller;
  final bool isObscured;
  final VoidCallback onToggle;
  final String? Function(String?)? validator;

  const _PasswordField({
    required this.label,
    required this.hint,
    required this.controller,
    required this.isObscured,
    required this.onToggle,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white,
              fontSize: 15, fontWeight: FontWeight.w500)),
          const SizedBox(height: 10),
          TextFormField(
            controller: controller,
            obscureText: isObscured,
            validator: validator,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                  color: Color(0xFF6B8A9E), fontSize: 14),
              prefixIcon: const Icon(Icons.lock_outline,
                  color: Color(0xFF00D1D1), size: 22),
              suffixIcon: IconButton(
                icon: Icon(
                  isObscured
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: const Color(0xFF00D1D1), size: 20,
                ),
                onPressed: onToggle,
              ),
              filled: true,
              fillColor: const Color(0xFF001A2C).withOpacity(0.6),
              errorStyle: const TextStyle(color: Colors.redAccent),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    BorderSide(color: Colors.white.withOpacity(0.05)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                    color: Color(0xFF00D1D1), width: 1),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide:
                    const BorderSide(color: Colors.redAccent, width: 1),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                    color: Colors.redAccent, width: 1.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}