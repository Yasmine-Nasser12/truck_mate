import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/user_provider.dart';
import '/providers/driver_provider.dart';
import '/screen/driver/trip_active_screen.dart';

class TripAssignedScreen extends StatelessWidget {
  const TripAssignedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ── الاسم من Provider ──
    final user = context.watch<UserProvider>();
    final displayName = user.fullName.isNotEmpty ? user.fullName : 'Driver';

    return Scaffold(
      backgroundColor: const Color(0xFF0D1F2D),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _buildHeader(displayName),
              const SizedBox(height: 16),
              _buildBadge('Assigned', const Color(0xFF00D5BE)),
              const SizedBox(height: 24),

              // Trip Card
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF152232),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: const Color(0xFF00D5BE).withOpacity(0.2),
                      width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Trip Ready to Start',
                              style: TextStyle(
                                  color: Color(0xFF00D5BE),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          Text('SHP-4521',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.45),
                                  fontSize: 13)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    _divider(),

                    // ROUTE
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ROUTE',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.4),
                                  fontSize: 11,
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 16),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(children: [
                                Container(
                                  width: 28,
                                  height: 28,
                                  decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color(0xFF00D5BE)),
                                  child: const Icon(Icons.circle,
                                      color: Colors.white, size: 10),
                                ),
                                Container(
                                    width: 2,
                                    height: 36,
                                    color: const Color(0xFF00D5BE)
                                        .withOpacity(0.3)),
                              ]),
                              const SizedBox(width: 14),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Pickup Location',
                                      style: TextStyle(
                                          color: Colors.white.withOpacity(0.45),
                                          fontSize: 12)),
                                  const SizedBox(height: 4),
                                  const Text(
                                      'Maadi Distribution Center, Cairo',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600)),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: const Color(0xFF00D5BE),
                                      width: 2),
                                ),
                                child: const Icon(Icons.location_on,
                                    color: Color(0xFF00D5BE), size: 14),
                              ),
                              const SizedBox(width: 14),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Drop-off Location',
                                      style: TextStyle(
                                          color: Colors.white.withOpacity(0.45),
                                          fontSize: 12)),
                                  const SizedBox(height: 4),
                                  Text(context.watch<DriverProvider>().activeTrip?.destination ?? 'New Cairo Tech Hub, Cairo',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),
                    _divider(),

                    // SCHEDULE
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('SCHEDULE',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.4),
                                  fontSize: 11,
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 12),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color:
                                  const Color(0xFF00D5BE).withOpacity(0.08),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: const Color(0xFF00D5BE)
                                      .withOpacity(0.2)),
                            ),
                            child: const Text('Ready to start',
                                style: TextStyle(
                                    color: Color(0xFF00D5BE), fontSize: 14)),
                          ),
                        ],
                      ),
                    ),

                    _divider(),

                    // SHIPMENT INFO
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('SHIPMENT INFORMATION',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.4),
                                  fontSize: 11,
                                  letterSpacing: 1.2,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 16),
                          _infoRow('Client', 'El-Ezz Steel'),
                          const SizedBox(height: 12),
                          _infoRow('Cargo Type', 'Electronics – Fragile'),
                          const SizedBox(height: 12),
                          _infoRow('Weight', '2,400 lbs'),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF59E0B).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: const Color(0xFFF59E0B)
                                      .withOpacity(0.4)),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.warning_amber_rounded,
                                    color: Color(0xFFF59E0B), size: 14),
                                SizedBox(width: 6),
                                Text('Fragile',
                                    style: TextStyle(
                                        color: Color(0xFFF59E0B),
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ── Start Trip ──
              GestureDetector(
                onTap: () {
                  context.read<DriverProvider>().startTrip();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const TripActiveScreen()),
                  );
                },
                child: Container(
                  width: double.infinity,
                  height: 54,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [Color(0xFF00D5BE), Color(0xFF00B4A0)]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xFF00D5BE).withOpacity(0.35),
                          blurRadius: 16,
                          offset: const Offset(0, 6))
                    ],
                  ),
                  alignment: Alignment.center,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 24),
                      SizedBox(width: 8),
                      Text('Start Trip',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // View Full Details
              GestureDetector(
                onTap: () {},
                child: Container(
                  width: double.infinity,
                  height: 54,
                  decoration: BoxDecoration(
                    color: const Color(0xFF152232),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white12),
                  ),
                  alignment: Alignment.center,
                  child: Text('View Full Details',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 15,
                          fontWeight: FontWeight.w500)),
                ),
              ),

              const SizedBox(height: 16),
              Row(children: [
                Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white24)),
                const SizedBox(width: 8),
                Text('Offline – Not receiving new trips',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 12)),
              ]),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(String displayName) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome back',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 13)),
              const SizedBox(height: 2),
              Text(
                displayName,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Container(
                  width: 60,
                  height: 2,
                  decoration: BoxDecoration(
                      color: const Color(0xFF00D5BE),
                      borderRadius: BorderRadius.circular(2))),
            ],
          ),
        ),
        _pill(child: const Row(children: [
          Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
          SizedBox(width: 4),
          Text('4.8', style: TextStyle(color: Colors.white, fontSize: 13)),
        ])),
        const SizedBox(width: 8),
        _pill(
            child: Row(children: [
          Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: Colors.white38)),
          const SizedBox(width: 6),
          const Text('OFFLINE',
              style: TextStyle(
                  color: Colors.white60,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
        ])),
        const SizedBox(width: 8),
        Container(
          width: 38,
          height: 38,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, color: Color(0xFF1E3040)),
          child: Icon(Icons.person_outline,
              color: Colors.white.withOpacity(0.7), size: 22),
        ),
      ],
    );
  }

  Widget _pill({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
            color: const Color(0xFF1E3040),
            borderRadius: BorderRadius.circular(20)),
        child: child,
      );

  Widget _buildBadge(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.4), width: 1),
        ),
        child: Text(text,
            style: TextStyle(
                color: color,
                fontSize: 13,
                fontWeight: FontWeight.w600)),
      );

  Widget _divider() =>
      Container(height: 1, color: Colors.white.withOpacity(0.06));

  Widget _infoRow(String label, String value) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.45), fontSize: 14)),
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
        ],
      );
}