import 'dart:math';
import 'package:flutter/material.dart';

// ══════════════════════════════════════════════════════
//  DRIVER EARNINGS SCREEN
// ══════════════════════════════════════════════════════

const Color _kBg       = Color(0xFF0D1F2D);
const Color _kCard     = Color(0xFF152232);
const Color _kPrimary  = Color(0xFF00D5BE);
const Color _kMuted    = Color(0xFF4A6572);
const Color _kDeep     = Color(0xFF0A1828);

class DriverEarningsScreen extends StatefulWidget {
  const DriverEarningsScreen({super.key});
  @override
  State<DriverEarningsScreen> createState() => _DriverEarningsScreenState();
}

class _DriverEarningsScreenState extends State<DriverEarningsScreen>
    with TickerProviderStateMixin {

  int _tab = 0; // 0=Today 1=This Week 2=This Month

  // ── dummy data per tab ──
  final _data = const [
    _EarningsData(
      label: 'Today Earnings',
      amount: 1250,
      currency: 'EGP',
      comparison: 'You earned 22% more than yesterday',
      payoutLabel: 'Next payout in 2 days',
      target: 1500,
      current: 1250,
      baseFare: 3200,
      distanceBonus: 1200,
      peakHours: 400,
      tips: 180,
      deductions: 120,
    ),
    _EarningsData(
      label: 'This Week Earnings',
      amount: 6800,
      currency: 'EGP',
      comparison: 'You earned 18% more than last week',
      payoutLabel: 'Next payout in 2 days',
      target: 8000,
      current: 6800,
      baseFare: 14200,
      distanceBonus: 5100,
      peakHours: 1800,
      tips: 620,
      deductions: 480,
    ),
    _EarningsData(
      label: 'This Month Earnings',
      amount: 12300,
      currency: 'EGP',
      comparison: 'You earned 15% more than last month',
      payoutLabel: 'Monthly payout on Dec 30',
      target: 18000,
      current: 12300,
      baseFare: 28400,
      distanceBonus: 9800,
      peakHours: 3200,
      tips: 1100,
      deductions: 980,
    ),
  ];

  late final AnimationController _cardCtrl;
  late final Animation<double> _cardAnim;
  late final AnimationController _ringCtrl;
  late final Animation<double> _ringAnim;

  @override
  void initState() {
    super.initState();
    _cardCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..forward();
    _cardAnim = CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic);
    _ringCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _ringAnim = CurvedAnimation(parent: _ringCtrl, curve: Curves.easeOutCubic);
  }

  void _switchTab(int i) {
    setState(() => _tab = i);
    _cardCtrl.forward(from: 0);
    _ringCtrl.forward(from: 0);
  }

  @override
  void dispose() {
    _cardCtrl.dispose();
    _ringCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = _data[_tab];
    final pct = (d.current / d.target).clamp(0.0, 1.0);
    final remaining = (d.target - d.current).clamp(0, 999999);

    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ──
              Row(children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _kCard,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: Colors.white, size: 18),
                  ),
                ),
                const SizedBox(width: 14),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Earnings',
                        style: TextStyle(color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.w800)),
                    Text('Your income summary',
                        style: TextStyle(color: _kMuted, fontSize: 13)),
                  ],
                ),
              ]),
              const SizedBox(height: 22),

              // ── Main earnings card ──
              FadeTransition(
                opacity: _cardAnim,
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
                      .animate(_cardAnim),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF00B4A0), Color(0xFF00D5BE), Color(0xFF00C8E8)],
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 44, height: 44,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(13),
                              ),
                              child: const Icon(Icons.account_balance_wallet_outlined,
                                  color: Colors.white, size: 22),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.25),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(width: 7, height: 7,
                                    decoration: const BoxDecoration(
                                        color: Colors.white, shape: BoxShape.circle)),
                                  const SizedBox(width: 6),
                                  Text(d.payoutLabel,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 12,
                                          fontWeight: FontWeight.w600)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Text(d.label,
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.85), fontSize: 13)),
                        const SizedBox(height: 6),
                        Text(
                          '${_fmt(d.amount)} ${d.currency}',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 38,
                              fontWeight: FontWeight.w800, letterSpacing: -1),
                        ),
                        const SizedBox(height: 14),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(d.comparison,
                              style: const TextStyle(color: Colors.white, fontSize: 13)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ── Tab selector ──
              Container(
                height: 48,
                decoration: BoxDecoration(
                  color: _kCard,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: List.generate(3, (i) {
                    final labels = ['Today', 'This Week', 'This Month'];
                    final active = _tab == i;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => _switchTab(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          margin: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: active ? _kPrimary : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          alignment: Alignment.center,
                          child: Text(labels[i],
                              style: TextStyle(
                                  color: active ? Colors.white : _kMuted,
                                  fontSize: 13,
                                  fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              const SizedBox(height: 16),

              // ── Target progress card ──
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _kCard,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Text('Target Progress',
                          style: TextStyle(color: _kMuted, fontSize: 13)),
                      const Spacer(),
                      const Text('Target',
                          style: TextStyle(color: _kMuted, fontSize: 12)),
                      const SizedBox(width: 6),
                      Text('${_fmt(d.target)} EGP',
                          style: const TextStyle(
                              color: _kPrimary, fontSize: 14,
                              fontWeight: FontWeight.w700)),
                    ]),
                    const SizedBox(height: 4),
                    Text('${(pct * 100).round()}% Complete',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 20),

                    // ── Ring ──
                    Center(
                      child: AnimatedBuilder(
                        animation: _ringAnim,
                        builder: (_, __) => SizedBox(
                          width: 180, height: 180,
                          child: CustomPaint(
                            painter: _RingPainter(
                              progress: pct * _ringAnim.value,
                              primaryColor: _kPrimary,
                              bgColor: _kDeep,
                            ),
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(_fmt(d.current),
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 32,
                                          fontWeight: FontWeight.w800)),
                                  const Text('Current',
                                      style: TextStyle(color: _kMuted, fontSize: 13)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: Text(
                        remaining > 0
                            ? '${_fmt(remaining)} EGP remaining to reach target'
                            : '🎉 Target reached!',
                        style: const TextStyle(color: _kMuted, fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── View Earnings History button ──
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const DriverEarningsHistoryScreen())),
                child: Container(
                  width: double.infinity,
                  height: 54,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF00B4A0), Color(0xFF00C8E8)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('View Earnings History',
                          style: TextStyle(
                              color: Colors.white, fontSize: 16,
                              fontWeight: FontWeight.w700)),
                      SizedBox(width: 8),
                      Icon(Icons.chevron_right_rounded, color: Colors.white, size: 22),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // ── How this was calculated ──
              GestureDetector(
                onTap: () => _showCalculationSheet(context, d),
                child: Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    color: _kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _kPrimary.withOpacity(0.3)),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.info_outline_rounded, color: _kPrimary, size: 18),
                      SizedBox(width: 8),
                      Text('How this was calculated',
                          style: TextStyle(color: _kPrimary, fontSize: 14,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCalculationSheet(BuildContext ctx, _EarningsData d) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _CalculationSheet(data: d),
    );
  }
}

// ── Calculation Bottom Sheet ──
class _CalculationSheet extends StatelessWidget {
  final _EarningsData data;
  const _CalculationSheet({required this.data});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Base Fare',      data.baseFare,      0.75),
      ('Distance Bonus', data.distanceBonus, 0.40),
      ('Peak Hours',     data.peakHours,     0.20),
      ('Tips',           data.tips,          0.15),
    ];

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      decoration: const BoxDecoration(
        color: Color(0xFF0F2030),
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('Calculation Breakdown',
              style: TextStyle(color: Colors.white, fontSize: 20,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('How your today earnings were calculated',
              style: TextStyle(color: _kMuted, fontSize: 13)),
          const SizedBox(height: 20),
          ...items.map((item) => _BreakdownRow(
            label: item.$1, amount: item.$2, barPct: item.$3)),
          if (data.deductions > 0) ...[
            const SizedBox(height: 6),
            _BreakdownRow(
              label: 'Deductions', amount: -data.deductions, barPct: 0.08,
              isNeg: true),
          ],
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              const Text('Net Earnings',
                  style: TextStyle(color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('${_fmt(data.amount)} EGP',
                  style: const TextStyle(
                      color: _kPrimary, fontSize: 18,
                      fontWeight: FontWeight.w800)),
            ]),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => const DriverEarningsBreakdownScreen()));
            },
            child: Container(
              width: double.infinity, height: 50,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF00B4A0), Color(0xFF00C8E8)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              alignment: Alignment.center,
              child: const Text('See Full Earnings Breakdown',
                  style: TextStyle(color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }
}

class _BreakdownRow extends StatelessWidget {
  final String label;
  final int amount;
  final double barPct;
  final bool isNeg;
  const _BreakdownRow({
    required this.label, required this.amount,
    required this.barPct, this.isNeg = false});

  @override
  Widget build(BuildContext context) {
    final color = isNeg ? const Color(0xFFFF476D) : _kPrimary;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Text(label, style: const TextStyle(color: _kMuted, fontSize: 13)),
            const Spacer(),
            Text(
              '${isNeg ? "-" : ""}${_fmt(amount.abs())} EGP',
              style: TextStyle(color: color, fontSize: 16,
                  fontWeight: FontWeight.w700),
            ),
          ]),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: barPct,
              minHeight: 5,
              backgroundColor: Colors.white12,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════
//  EARNINGS HISTORY SCREEN
// ══════════════════════════════════════════════════════
class DriverEarningsHistoryScreen extends StatefulWidget {
  const DriverEarningsHistoryScreen({super.key});
  @override
  State<DriverEarningsHistoryScreen> createState() => _EarningsHistoryState();
}

class _EarningsHistoryState extends State<DriverEarningsHistoryScreen> {
  int _filter = 0; // 0=All 1=Paid 2=Pending

  final _allTrips = const [
    _TripItem('Maadi → Nasr City',        'Dec 16, 2025', 'TR-4721', 850,  true),
    _TripItem('Downtown → Heliopolis',    'Dec 16, 2025', 'TR-4720', 620,  true),
    _TripItem('Zamalek → New Cairo',      'Dec 15, 2025', 'TR-4719', 1150, false),
    _TripItem('6th October → Maadi',      'Dec 15, 2025', 'TR-4718', 730,  true),
    _TripItem('Nasr City → Dokki',        'Dec 14, 2025', 'TR-4717', 540,  true),
    _TripItem('Heliopolis → Sheikh Zayed','Dec 14, 2025', 'TR-4716', 920,  false),
    _TripItem('Mohandessin → New Cairo',  'Dec 13, 2025', 'TR-4715', 1080, true),
    _TripItem('Maadi → Zamalek',          'Dec 13, 2025', 'TR-4714', 490,  true),
    _TripItem('New Cairo → Downtown',     'Dec 12, 2025', 'TR-4713', 870,  false),
    _TripItem('Dokki → 6th October',      'Dec 12, 2025', 'TR-4712', 650,  true),
  ];

  List<_TripItem> get _filtered {
    if (_filter == 1) return _allTrips.where((t) => t.isPaid).toList();
    if (_filter == 2) return _allTrips.where((t) => !t.isPaid).toList();
    return _allTrips;
  }

  @override
  Widget build(BuildContext context) {
    final trips = _filtered;
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                        color: _kCard, borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: Colors.white, size: 18),
                  ),
                ),
                const SizedBox(width: 14),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Earnings History',
                        style: TextStyle(color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.w800)),
                    Text('Completed trips & payouts',
                        style: TextStyle(color: _kMuted, fontSize: 13)),
                  ],
                ),
              ]),
              const SizedBox(height: 20),

              // Filter tabs
              Container(
                height: 48,
                decoration: BoxDecoration(
                    color: _kCard, borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: List.generate(3, (i) {
                    final labels = ['All', 'Paid', 'Pending'];
                    final active = _filter == i;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _filter = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: active ? _kPrimary : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          alignment: Alignment.center,
                          child: Text(labels[i],
                              style: TextStyle(
                                  color: active ? Colors.white : _kMuted,
                                  fontSize: 13,
                                  fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              const SizedBox(height: 16),

              // Trip list
              Expanded(
                child: ListView.separated(
                  itemCount: trips.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) => _TripTile(trip: trips[i]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TripTile extends StatelessWidget {
  final _TripItem trip;
  const _TripTile({required this.trip});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(trip.route,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Row(children: [
                Text(trip.date,
                    style: const TextStyle(color: _kMuted, fontSize: 12)),
                const SizedBox(width: 8),
                Container(width: 4, height: 4,
                    decoration: const BoxDecoration(
                        color: _kMuted, shape: BoxShape.circle)),
                const SizedBox(width: 8),
                Text(trip.ref,
                    style: const TextStyle(color: _kMuted, fontSize: 12)),
              ]),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('+${_fmt(trip.amount)} EGP',
                style: const TextStyle(
                    color: _kPrimary, fontSize: 15,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: trip.isPaid
                    ? _kPrimary.withOpacity(0.15)
                    : const Color(0xFFFF8904).withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                trip.isPaid ? 'Paid' : 'Pending',
                style: TextStyle(
                    color: trip.isPaid ? _kPrimary : const Color(0xFFFF8904),
                    fontSize: 11, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════
//  EARNINGS BREAKDOWN SCREEN
// ══════════════════════════════════════════════════════
class DriverEarningsBreakdownScreen extends StatefulWidget {
  const DriverEarningsBreakdownScreen({super.key});
  @override
  State<DriverEarningsBreakdownScreen> createState() =>
      _EarningsBreakdownState();
}

class _EarningsBreakdownState extends State<DriverEarningsBreakdownScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final List<Animation<double>> _anims;

  final _factors = const [
    _Factor('18 trips this week',    Icons.location_on_outlined,
        '8,460 EGP total from completed trips',
        'Contribution', 1.0, '100%'),
    _Factor('Long-distance trips',   Icons.bolt_outlined,
        '5,200 EGP from trips over 20km',
        'Most earnings came from these', 0.61, '61%'),
    _Factor('Weekend earnings',      Icons.access_time_outlined,
        '3,100 EGP earned on weekends',
        'You earn more on weekends', 0.37, '37%'),
  ];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..forward();
    _anims = List.generate(_factors.length, (i) {
      final start = i * 0.15;
      return CurvedAnimation(
        parent: _ctrl,
        curve: Interval(start, (start + 0.5).clamp(0.0, 1.0), curve: Curves.easeOutCubic),
      );
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                        color: _kCard, borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: Colors.white, size: 18),
                  ),
                ),
                const SizedBox(width: 14),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Earnings Breakdown',
                        style: TextStyle(color: Colors.white, fontSize: 20,
                            fontWeight: FontWeight.w800)),
                    Text('Where your money comes from',
                        style: TextStyle(color: _kMuted, fontSize: 13)),
                  ],
                ),
              ]),
              const SizedBox(height: 22),

              // Primary metric card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                    color: _kCard, borderRadius: BorderRadius.circular(18)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Expanded(
                        child: Text('Primary Metric',
                            style: TextStyle(color: _kMuted, fontSize: 12)),
                      ),
                      Container(
                        width: 40, height: 40,
                        decoration: BoxDecoration(
                          color: _kPrimary.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.trending_up_rounded,
                            color: _kPrimary, size: 20),
                      ),
                    ]),
                    const SizedBox(height: 4),
                    const Text('Average Earnings per Trip',
                        style: TextStyle(color: Colors.white, fontSize: 16,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    const Text('470 EGP',
                        style: TextStyle(color: _kPrimary, fontSize: 38,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _kDeep,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                          'This is 18% higher than the platform average',
                          style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              const Text('CONTRIBUTING FACTORS',
                  style: TextStyle(color: _kMuted, fontSize: 11,
                      letterSpacing: 1.4, fontWeight: FontWeight.w600)),
              const SizedBox(height: 14),

              // Factor cards
              ...List.generate(_factors.length, (i) {
                final f = _factors[i];
                return FadeTransition(
                  opacity: _anims[i],
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.15), end: Offset.zero)
                      .animate(_anims[i]),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                          color: _kCard, borderRadius: BorderRadius.circular(16)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Container(
                              width: 38, height: 38,
                              decoration: BoxDecoration(
                                color: _kPrimary.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(f.icon, color: _kPrimary, size: 18),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(f.title,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 15,
                                          fontWeight: FontWeight.w700)),
                                  const SizedBox(height: 2),
                                  Text(f.subtitle,
                                      style: const TextStyle(
                                          color: _kMuted, fontSize: 11)),
                                ],
                              ),
                            ),
                          ]),
                          const SizedBox(height: 12),
                          Row(children: [
                            Text(f.barLabel,
                                style: const TextStyle(
                                    color: _kMuted, fontSize: 12)),
                            const Spacer(),
                            Text(f.pctLabel,
                                style: const TextStyle(
                                    color: _kPrimary, fontSize: 13,
                                    fontWeight: FontWeight.w700)),
                          ]),
                          const SizedBox(height: 6),
                          AnimatedBuilder(
                            animation: _anims[i],
                            builder: (_, __) => ClipRRect(
                              borderRadius: BorderRadius.circular(99),
                              child: LinearProgressIndicator(
                                value: f.barValue * _anims[i].value,
                                minHeight: 5,
                                backgroundColor: Colors.white12,
                                valueColor: const AlwaysStoppedAnimation<Color>(_kPrimary),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),

              const SizedBox(height: 4),

              // Key insight card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _kCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _kPrimary.withOpacity(0.2)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: _kPrimary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.trending_up_rounded,
                          color: _kPrimary, size: 18),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('KEY INSIGHT',
                              style: TextStyle(
                                  color: _kPrimary, fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.2)),
                          SizedBox(height: 6),
                          Text(
                            'Most of your earnings came from long-distance trips during peak hours',
                            style: TextStyle(color: Colors.white,
                                fontSize: 14, fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Consider accepting more trips over 20km for higher earnings',
                            style: TextStyle(color: _kMuted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // CTA button
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const DriverEarningsHistoryScreen())),
                child: Container(
                  width: double.infinity, height: 54,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF00B4A0), Color(0xFF00C8E8)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('See full trip breakdown',
                          style: TextStyle(color: Colors.white, fontSize: 16,
                              fontWeight: FontWeight.w700)),
                      SizedBox(width: 8),
                      Icon(Icons.chevron_right_rounded,
                          color: Colors.white, size: 22),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Ring painter ──
class _RingPainter extends CustomPainter {
  final double progress;
  final Color primaryColor;
  final Color bgColor;
  const _RingPainter({required this.progress, required this.primaryColor, required this.bgColor});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2, cy = size.height / 2;
    final radius = min(cx, cy) - 14;
    final stroke = 14.0;

    final bgPaint = Paint()
      ..color = bgColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(Offset(cx, cy), radius, bgPaint);

    final fgPaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: Offset(cx, cy), radius: radius),
      -pi / 2,
      2 * pi * progress,
      false,
      fgPaint,
    );
  }

  @override
  bool shouldRepaint(_RingPainter old) => old.progress != progress;
}

// ── Data models ──
class _EarningsData {
  final String label, currency, comparison, payoutLabel;
  final int amount, target, current, baseFare, distanceBonus, peakHours, tips, deductions;
  const _EarningsData({
    required this.label, required this.amount, required this.currency,
    required this.comparison, required this.payoutLabel,
    required this.target, required this.current, required this.baseFare,
    required this.distanceBonus, required this.peakHours,
    required this.tips, required this.deductions,
  });
}

class _TripItem {
  final String route, date, ref;
  final int amount;
  final bool isPaid;
  const _TripItem(this.route, this.date, this.ref, this.amount, this.isPaid);
}

class _Factor {
  final String title, subtitle, barLabel, pctLabel;
  final IconData icon;
  final double barValue;
  const _Factor(this.title, this.icon, this.subtitle, this.barLabel, this.barValue, this.pctLabel);
}

String _fmt(int n) {
  if (n >= 1000) {
    final s = n.toString();
    final buf = StringBuffer();
    final mod = s.length % 3;
    for (int i = 0; i < s.length; i++) {
      if (i != 0 && (i - mod) % 3 == 0) buf.write(',');
      buf.write(s[i]);
    }
    return buf.toString();
  }
  return n.toString();
}