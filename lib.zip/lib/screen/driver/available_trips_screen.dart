import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/driver_provider.dart';
import '/models/driver_models.dart';
import '/screen/driver/trip_assigned_screen.dart';

class AvailableTripsScreen extends StatelessWidget {
  const AvailableTripsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final driver = context.watch<DriverProvider>();
    final trips = driver.availableTrips;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1F2D),
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E3040),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.arrow_back_rounded,
                          color: Color(0xFF00D5BE), size: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Available Trips',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700)),
                      Text('${trips.length} trips near you',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.4),
                              fontSize: 13)),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── List ──
            Expanded(
              child: trips.isEmpty
                  ? _emptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: trips.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (ctx, i) => _TripCard(
                        trip: trips[i],
                        onAccept: () => _handleAccept(ctx, trips[i]),
                        onReject: () =>
                            ctx.read<DriverProvider>().rejectTrip(trips[i]),
                      ),
                    ),
            ),

            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _handleAccept(BuildContext context, AvailableTrip trip) {
    context.read<DriverProvider>().acceptTrip(trip);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const TripAssignedScreen()),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF00D5BE).withOpacity(0.1),
            ),
            child: const Icon(Icons.inbox_outlined,
                color: Color(0xFF00D5BE), size: 34),
          ),
          const SizedBox(height: 16),
          const Text('No trips available right now',
              style: TextStyle(color: Colors.white, fontSize: 16)),
          const SizedBox(height: 8),
          Text('Check back soon for new shipments',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.4), fontSize: 13)),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════
//  TRIP CARD
// ══════════════════════════════════════════
class _TripCard extends StatefulWidget {
  final AvailableTrip trip;
  final VoidCallback onAccept;
  final VoidCallback onReject;

  const _TripCard({
    required this.trip,
    required this.onAccept,
    required this.onReject,
  });

  @override
  State<_TripCard> createState() => _TripCardState();
}

class _TripCardState extends State<_TripCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final t = widget.trip;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: const Color(0xFF152232),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: const Color(0xFF00D5BE).withOpacity(0.15), width: 0.8),
      ),
      child: Column(
        children: [
          // ── Main Info ──
          GestureDetector(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top row: ID + Price
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(t.id,
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.4),
                              fontSize: 12)),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00D5BE).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${t.price.toStringAsFixed(0)} EGP',
                          style: const TextStyle(
                              color: Color(0xFF00D5BE),
                              fontSize: 13,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Route
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(children: [
                        Container(
                            width: 10, height: 10,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFF00D5BE))),
                        Container(
                            width: 1.5, height: 32,
                            color: const Color(0xFF00D5BE).withOpacity(0.3)),
                        Container(
                            width: 10, height: 10,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFF0E8FD4))),
                      ]),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(t.origin,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 14),
                            Text(t.destination,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Stats row
                  Row(
                    children: [
                      _statChip(Icons.route_outlined, t.distance),
                      const SizedBox(width: 8),
                      _statChip(Icons.access_time_outlined, t.estimatedTime),
                      const SizedBox(width: 8),
                      _statChip(Icons.monitor_weight_outlined,
                          '${t.weightTons} ton'),
                    ],
                  ),

                  // Tags
                  if (t.isFragile || t.isRefrigerated) ...[
                    const SizedBox(height: 10),
                    Row(children: [
                      if (t.isFragile) ...[
                        _tag(Icons.warning_amber_rounded, 'Fragile',
                            const Color(0xFFF59E0B)),
                        const SizedBox(width: 8),
                      ],
                      if (t.isRefrigerated)
                        _tag(Icons.thermostat_outlined, 'Refrigerated',
                            const Color(0xFF00D3F2)),
                    ]),
                  ],

                  // Expand indicator
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _expanded
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down,
                        color: Colors.white.withOpacity(0.3),
                        size: 20,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // ── Expanded Details ──
          if (_expanded) ...[
            Divider(
                color: Colors.white.withOpacity(0.07),
                height: 1),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Trader info
                  Row(children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFF00D5BE).withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          t.traderName.substring(0, 1),
                          style: const TextStyle(
                              color: Color(0xFF00D5BE),
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Column(crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      const Text('Trader',
                          style: TextStyle(
                              color: Color(0xFF6B8A9E), fontSize: 11)),
                      Text(t.traderName,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600)),
                    ]),
                    const Spacer(),
                    Row(children: [
                      const Icon(Icons.star,
                          color: Color(0xFFF59E0B), size: 14),
                      const SizedBox(width: 4),
                      Text(t.traderRating,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 13)),
                    ]),
                  ]),

                  const SizedBox(height: 14),
                  Divider(color: Colors.white.withOpacity(0.07), height: 1),
                  const SizedBox(height: 14),

                  // Goods info
                  _detailRow('Cargo', t.goodsType),
                  const SizedBox(height: 8),
                  _detailRow('Scheduled', '${t.scheduledDate} · ${t.scheduledTime}'),
                ],
              ),
            ),
          ],

          // ── Accept / Reject Buttons ──
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              children: [
                // Reject
                Expanded(
                  child: GestureDetector(
                    onTap: widget.onReject,
                    child: Container(
                      height: 46,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E3040),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      alignment: Alignment.center,
                      child: Text('Reject',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 14,
                              fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Accept
                Expanded(
                  flex: 2,
                  child: GestureDetector(
                    onTap: widget.onAccept,
                    child: Container(
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF00D5BE), Color(0xFF00B4A0)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                              color: const Color(0xFF00D5BE).withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 4)),
                        ],
                      ),
                      alignment: Alignment.center,
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_rounded,
                              color: Colors.white, size: 18),
                          SizedBox(width: 6),
                          Text('Accept Trip',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1F2D),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(children: [
        Icon(icon, color: const Color(0xFF00D5BE), size: 13),
        const SizedBox(width: 5),
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.7), fontSize: 11)),
      ]),
    );
  }

  Widget _tag(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 12),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                color: color, fontSize: 11, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _detailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.4), fontSize: 13)),
        Text(value,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500)),
      ],
    );
  }
}