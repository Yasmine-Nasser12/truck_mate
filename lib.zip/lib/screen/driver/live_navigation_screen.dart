import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class LiveNavigationScreen extends StatefulWidget {
  const LiveNavigationScreen({super.key});

  @override
  State<LiveNavigationScreen> createState() => _LiveNavigationScreenState();
}

class _LiveNavigationScreenState extends State<LiveNavigationScreen>
    with SingleTickerProviderStateMixin {

  final LatLng _pickup      = const LatLng(29.9602, 31.2569);
  final LatLng _driverPos   = const LatLng(29.9800, 31.3200);
  final LatLng _destination = const LatLng(30.0131, 31.4665);

  late final MapController _mapCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  @override
  void initState() {
    super.initState();
    _mapCtrl = MapController();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 8.0, end: 20.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final mapH = h * 0.56;

    return Scaffold(
      backgroundColor: const Color(0xFF0D1F2D),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: mapH,
              child: Stack(
                children: [
                  FlutterMap(
                    mapController: _mapCtrl,
                    options: MapOptions(
                      initialCenter: _driverPos,
                      initialZoom: 12.5,
                    ),
                    children: [
                      TileLayer(
                        urlTemplate:
                            'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
                        subdomains: const ['a', 'b', 'c', 'd'],
                        userAgentPackageName: 'com.truckmate.app',
                      ),
                      PolylineLayer(
                        polylines: [
                          Polyline(
                            points: [_pickup, _driverPos, _destination],
                            color: const Color(0xFF00D5BE),
                            strokeWidth: 4.0,
                            borderColor: const Color(0xFF00D5BE),
                            borderStrokeWidth: 10,
                          ),
                        ],
                      ),
                      MarkerLayer(
                        markers: [
                          // Pickup
                          Marker(
                            point: _pickup,
                            width: 28, height: 28,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFFEF4444),
                                border: Border.all(color: Colors.white, width: 2),
                                boxShadow: [BoxShadow(
                                  color: const Color(0xFFEF4444).withOpacity(0.5),
                                  blurRadius: 8)],
                              ),
                            ),
                          ),
                          // Driver
                          Marker(
                            point: _driverPos,
                            width: 60, height: 60,
                            child: AnimatedBuilder(
                              animation: _pulseAnim,
                              builder: (_, __) => Stack(
                                alignment: Alignment.center,
                                children: [
                                  Container(
                                    width: _pulseAnim.value * 2,
                                    height: _pulseAnim.value * 2,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: const Color(0xFF00D5BE).withOpacity(0.2),
                                    ),
                                  ),
                                  Container(
                                    width: 40, height: 40,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color(0xFF00D5BE),
                                      boxShadow: [BoxShadow(
                                        color: Color(0x9900D5BE),
                                        blurRadius: 16, spreadRadius: 2)],
                                    ),
                                    child: const Icon(Icons.navigation,
                                        color: Colors.white, size: 22),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // Destination
                          Marker(
                            point: _destination,
                            width: 32, height: 32,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF00D5BE),
                                border: Border.all(color: Colors.white, width: 2),
                                boxShadow: [BoxShadow(
                                  color: const Color(0xFF00D5BE).withOpacity(0.6),
                                  blurRadius: 10)],
                              ),
                              child: const Icon(Icons.location_on,
                                  color: Colors.white, size: 16),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Back button
                  Positioned(
                    top: 16, left: 16,
                    child: _MapButton(
                      icon: Icons.arrow_back,
                      onTap: () => Navigator.pop(context),
                    ),
                  ),

                  // Center button
                  Positioned(
                    top: 16, right: 16,
                    child: _MapButton(
                      icon: Icons.my_location,
                      onTap: () => _mapCtrl.move(_driverPos, 13.0),
                    ),
                  ),

                  // Direction card
                  Positioned(
                    top: 16, left: 70, right: 70,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF152232).withOpacity(0.95),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 10, offset: const Offset(0, 4))],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 32, height: 32,
                            decoration: BoxDecoration(
                              color: const Color(0xFF00D5BE).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.turn_right,
                                color: Color(0xFF00D5BE), size: 18),
                          ),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Turn right on Ring Road',
                                    style: TextStyle(color: Colors.white,
                                        fontSize: 12, fontWeight: FontWeight.w600)),
                                SizedBox(height: 2),
                                Text('in 0.5 mi',
                                    style: TextStyle(color: Color(0xFF00D5BE), fontSize: 11)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Trip info bottom sheet
            Expanded(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: Color(0xFF152232),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('ETA', style: TextStyle(
                                  color: Colors.white.withOpacity(0.45), fontSize: 12)),
                              const SizedBox(height: 4),
                              const Text('38 min', style: TextStyle(
                                  color: Color(0xFF00D5BE), fontSize: 28,
                                  fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                        Container(width: 1, height: 40,
                            color: Colors.white.withOpacity(0.08)),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Distance', style: TextStyle(
                                    color: Colors.white.withOpacity(0.45), fontSize: 12)),
                                const SizedBox(height: 4),
                                const Text('12.4 mi', style: TextStyle(
                                    color: Colors.white, fontSize: 22,
                                    fontWeight: FontWeight.w700)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Container(height: 1, color: Colors.white.withOpacity(0.07)),
                    const SizedBox(height: 14),
                    Text('Destination', style: TextStyle(
                        color: Colors.white.withOpacity(0.4), fontSize: 12)),
                    const SizedBox(height: 4),
                    const Text('New Cairo Tech Hub', style: TextStyle(
                        color: Colors.white, fontSize: 17,
                        fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text('SHP-4521', style: TextStyle(
                        color: Colors.white.withOpacity(0.35), fontSize: 13)),
                    const Spacer(),
                    Row(
                      children: [
                        Expanded(
                          child: _ActionButton(
                            icon: Icons.phone_outlined,
                            label: 'Contact',
                            color: const Color(0xFF1E3040),
                            onTap: () {},
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: _ActionButton(
                            icon: Icons.timer_outlined,
                            label: 'End Trip',
                            color: const Color(0xFFEF4444),
                            isRed: true,
                            onTap: () => Navigator.pop(context),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _MapButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: const Color(0xFF152232).withOpacity(0.95),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool isRed;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.isRed = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
          boxShadow: isRed ? [BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.35),
            blurRadius: 14, offset: const Offset(0, 4))] : [],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(
                color: Colors.white, fontSize: 15,
                fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
