import 'package:flutter/material.dart';

// ══════════════════════════════════════════
//  COLORS
// ══════════════════════════════════════════
const Color kBg = Color(0xFF0F2334);
const Color kCardBg = Color(0xFF112236);
const Color kActiveBg = Color(0xFF0E2035);
const Color kCyan = Color(0xFF00D4E0);
const Color kTeal = Color(0xFF00D5BE);
const Color kOrange = Color(0xFFFF8904);
const Color kTextWhite = Color(0xFFE8F0F8);
const Color kTextGrey = Color(0xFF5F7E97);
const Color kDetailBg = Color(0xFF0B1E2E);

// ══════════════════════════════════════════
//  MODEL
// ══════════════════════════════════════════
enum TripStatus { inProgress, scheduled, completed }
enum FilterType { all, upcoming, completed }

class TripModel {
  final String id;
  final String date;
  final String from;
  final String to;
  final int miles;
  final TripStatus status;
  final double? progress;

  const TripModel({
    required this.id,
    required this.date,
    required this.from,
    required this.to,
    required this.miles,
    required this.status,
    this.progress,
  });
}

const List<TripModel> kTrips = [
  TripModel(id: 'TR-4721', date: 'Dec 16, 2025', from: 'Nasr City',
      to: 'Maadi', miles: 382, status: TripStatus.inProgress, progress: 0.47),
  TripModel(id: 'TR-4722', date: 'Dec 17, 2025', from: 'Maadi',
      to: 'Nasr City', miles: 124, status: TripStatus.scheduled),
  TripModel(id: 'TR-4723', date: 'Dec 17, 2025', from: 'Maadi',
      to: 'Zamalik', miles: 355, status: TripStatus.scheduled),
  TripModel(id: 'TR-4718', date: 'Dec 14, 2025', from: 'Zamalik',
      to: 'Dokki', miles: 87, status: TripStatus.completed),
  TripModel(id: 'TR-4715', date: 'Dec 14, 2025', from: 'Zamalik',
      to: 'Dokki', miles: 52, status: TripStatus.completed),
];

// ══════════════════════════════════════════
//  TRIPS SCREEN  ← غيرنا من Page لـ Screen
// ══════════════════════════════════════════
class TripsScreen extends StatefulWidget {
  const TripsScreen({super.key});

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen> with TickerProviderStateMixin {
  FilterType _filter = FilterType.all;
  late final AnimationController _pageCtrl;
  late final List<Animation<double>> _itemAnims;

  @override
  void initState() {
    super.initState();
    _pageCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _itemAnims = List.generate(8, (i) {
      final start = (i * 0.09).clamp(0.0, 0.8);
      final end = (start + 0.4).clamp(0.0, 1.0);
      return CurvedAnimation(
        parent: _pageCtrl,
        curve: Interval(start, end, curve: Curves.easeOutCubic),
      );
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  List<TripModel> get _filteredOthers {
    final others = kTrips.where((t) => t.status != TripStatus.inProgress).toList();
    switch (_filter) {
      case FilterType.upcoming:
        return others.where((t) => t.status == TripStatus.scheduled).toList();
      case FilterType.completed:
        return others.where((t) => t.status == TripStatus.completed).toList();
      case FilterType.all:
        return others;
    }
  }

  bool get _showActive =>
      _filter == FilterType.all || _filter == FilterType.upcoming;

  void _openFilter() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => FilterSheet(
        current: _filter,
        onSelect: (f) {
          setState(() => _filter = f);
          Navigator.pop(context);
        },
      ),
    );
  }

  void _openDetail(TripModel trip) {
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 450),
        pageBuilder: (_, __, ___) => TripDetailPage(trip: trip),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.06),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            ),
          );
        },
      ),
    );
  }

  Widget _animItem(int index, Widget child) {
    final anim = _itemAnims[index.clamp(0, _itemAnims.length - 1)];
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Opacity(
        opacity: anim.value,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - anim.value)),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final active = kTrips.firstWhere((t) => t.status == TripStatus.inProgress);
    final others = _filteredOthers;

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            _animItem(
              0,
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 22, 16, 0),
                child: Row(
                  children: [
                    // ── زرار رجوع ──
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 36, height: 36,
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          color: kCardBg,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: kCyan, size: 18),
                      ),
                    ),
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Trips', style: TextStyle(
                            color: kTextWhite, fontSize: 22,
                            fontWeight: FontWeight.w700)),
                        SizedBox(height: 2),
                        Text('Manage your deliveries',
                            style: TextStyle(color: kTextGrey, fontSize: 12.5)),
                      ],
                    ),
                    const Spacer(),
                    _FilterButton(
                      active: _filter != FilterType.all,
                      onTap: _openFilter,
                    ),
                  ],
                ),
              ),
            ),

            if (_filter != FilterType.all)
              _animItem(1, Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: _FilterTag(
                    label: _filter == FilterType.upcoming ? 'Upcoming' : 'Completed',
                    onRemove: () => setState(() => _filter = FilterType.all),
                  ),
                ),
              )),

            const SizedBox(height: 20),

            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                physics: const BouncingScrollPhysics(),
                children: [
                  if (_showActive) ...[
                    _animItem(1, const _SectionLabel('Active Now')),
                    const SizedBox(height: 10),
                    _animItem(2, _ActiveCard(
                        trip: active, onTap: () => _openDetail(active))),
                    const SizedBox(height: 20),
                  ],
                  _animItem(3, const _SectionLabel('Other Trips')),
                  const SizedBox(height: 10),
                  for (int i = 0; i < others.length; i++)
                    _animItem(4 + i, Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _OtherCard(
                          trip: others[i], onTap: () => _openDetail(others[i])),
                    )),
                  const SizedBox(height: 8),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _Dot(color: kOrange),
                  _Dot(color: kTextGrey.withOpacity(0.35)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  FILTER BUTTON
// ══════════════════════════════════════════
class _FilterButton extends StatefulWidget {
  final bool active;
  final VoidCallback onTap;
  const _FilterButton({required this.active, required this.onTap});
  @override
  State<_FilterButton> createState() => _FilterButtonState();
}

class _FilterButtonState extends State<_FilterButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _scale = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.28), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.28, end: 0.88), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 0.88, end: 1.0), weight: 30),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _onTap() { _ctrl.forward(from: 0); widget.onTap(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onTap,
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, child) => Transform.scale(scale: _scale.value, child: child),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: widget.active ? kTeal.withOpacity(0.3) : kCardBg,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.filter_alt_outlined, color: kCyan, size: 20),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  FILTER TAG
// ══════════════════════════════════════════
class _FilterTag extends StatelessWidget {
  final String label;
  final VoidCallback onRemove;
  const _FilterTag({required this.label, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 5, 8, 5),
      decoration: BoxDecoration(
        color: kTeal.withOpacity(0.15),
        border: Border.all(color: kTeal.withOpacity(0.3)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(
              color: kTeal, fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: onRemove,
            child: Container(
              width: 16, height: 16,
              decoration: BoxDecoration(
                  color: kTeal.withOpacity(0.2), shape: BoxShape.circle),
              child: const Icon(Icons.close, color: kTeal, size: 10),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════
//  ACTIVE CARD
// ══════════════════════════════════════════
class _ActiveCard extends StatefulWidget {
  final TripModel trip;
  final VoidCallback onTap;
  const _ActiveCard({required this.trip, required this.onTap});
  @override
  State<_ActiveCard> createState() => _ActiveCardState();
}

class _ActiveCardState extends State<_ActiveCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _progressCtrl;
  late final Animation<double> _progressAnim;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _progressCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1100));
    _progressAnim = CurvedAnimation(
        parent: _progressCtrl, curve: Curves.easeOutCubic);
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _progressCtrl.forward();
    });
  }

  @override
  void dispose() { _progressCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final pct = ((widget.trip.progress ?? 0) * 100).round();
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        child: Container(
          decoration: BoxDecoration(
            color: kActiveBg,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: kCyan.withOpacity(0.10)),
          ),
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      color: kCyan.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Transform.rotate(
                      angle: 0.785,
                      child: const Icon(Icons.navigation_rounded,
                          color: kCyan, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Trip #${widget.trip.id}',
                          style: const TextStyle(color: kTextWhite,
                              fontSize: 14.5, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(widget.trip.date,
                          style: const TextStyle(color: kTextGrey, fontSize: 11.5)),
                    ],
                  ),
                  const Spacer(),
                  _StatusBadge(status: widget.trip.status),
                ],
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  const Icon(Icons.location_on_outlined,
                      color: Color(0x8000D5BE), size: 14),
                  const SizedBox(width: 5),
                  Text('${widget.trip.from}  →  ${widget.trip.to}',
                      style: const TextStyle(color: kTextWhite, fontSize: 13)),
                  const Spacer(),
                  Text('${widget.trip.miles} mi',
                      style: const TextStyle(color: kTextGrey, fontSize: 12.5)),
                ],
              ),
              const SizedBox(height: 13),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Progress',
                      style: TextStyle(color: kTextGrey, fontSize: 11.5)),
                  Text('$pct%', style: const TextStyle(
                      color: kCyan, fontSize: 11.5, fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 6),
              AnimatedBuilder(
                animation: _progressAnim,
                builder: (_, __) => ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: (widget.trip.progress ?? 0) * _progressAnim.value,
                    minHeight: 5,
                    backgroundColor: const Color(0xFF1B3A52),
                    valueColor: const AlwaysStoppedAnimation<Color>(kCyan),
                  ),
                ),
              ),
              const SizedBox(height: 13),
              const Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text('View Details', style: TextStyle(
                      color: kCyan, fontSize: 12.5, fontWeight: FontWeight.w500)),
                  SizedBox(width: 2),
                  Icon(Icons.chevron_right_rounded, color: kCyan, size: 18),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  OTHER CARD
// ══════════════════════════════════════════
class _OtherCard extends StatefulWidget {
  final TripModel trip;
  final VoidCallback onTap;
  const _OtherCard({required this.trip, required this.onTap});
  @override
  State<_OtherCard> createState() => _OtherCardState();
}

class _OtherCardState extends State<_OtherCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOutCubic,
        child: Container(
          decoration: BoxDecoration(
              color: kCardBg, borderRadius: BorderRadius.circular(13)),
          padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Trip #${widget.trip.id}',
                      style: const TextStyle(color: kTextWhite,
                          fontSize: 13.5, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  _StatusBadge(status: widget.trip.status),
                ],
              ),
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.calendar_today_outlined,
                    color: kTextGrey, size: 13),
                const SizedBox(width: 5),
                Text(widget.trip.date,
                    style: const TextStyle(color: kTextGrey, fontSize: 11.5)),
              ]),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(Icons.location_on_outlined,
                      color: Color(0x8000D5BE), size: 13),
                  const SizedBox(width: 5),
                  Text('${widget.trip.from}  →  ${widget.trip.to}',
                      style: const TextStyle(color: kTextWhite, fontSize: 12.5)),
                  const Spacer(),
                  Text('${widget.trip.miles} mi',
                      style: const TextStyle(color: kTextGrey, fontSize: 11.5)),
                  const SizedBox(width: 4),
                  const Icon(Icons.chevron_right_rounded,
                      color: kTextGrey, size: 18),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  STATUS BADGE
// ══════════════════════════════════════════
class _StatusBadge extends StatelessWidget {
  final TripStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    late final Color color;
    late final String label;
    switch (status) {
      case TripStatus.inProgress: color = kCyan;   label = 'In Progress'; break;
      case TripStatus.scheduled:  color = kOrange; label = 'Scheduled';   break;
      case TripStatus.completed:  color = kTeal;   label = 'Completed';   break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        border: Border.all(color: color.withOpacity(0.45)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label, style: TextStyle(
          color: color, fontSize: 10.5, fontWeight: FontWeight.w600)),
    );
  }
}

// ══════════════════════════════════════════
//  FILTER SHEET
// ══════════════════════════════════════════
class FilterSheet extends StatelessWidget {
  final FilterType current;
  final ValueChanged<FilterType> onSelect;
  const FilterSheet({super.key, required this.current, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1E2E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 4,
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.12),
                borderRadius: BorderRadius.circular(3)),
          ),
          Row(
            children: [
              const Text('Filter Trips', style: TextStyle(
                  color: kTextWhite, fontSize: 15, fontWeight: FontWeight.w600)),
              const Spacer(),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 28, height: 28,
                  decoration: const BoxDecoration(
                      color: Color(0xFF1A3550), shape: BoxShape.circle),
                  child: const Icon(Icons.close, color: kTextWhite, size: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _FilterOption(label: 'All Trips',
              selected: current == FilterType.all,
              onTap: () => onSelect(FilterType.all)),
          const SizedBox(height: 10),
          _FilterOption(label: 'Upcoming',
              selected: current == FilterType.upcoming,
              onTap: () => onSelect(FilterType.upcoming)),
          const SizedBox(height: 10),
          _FilterOption(label: 'Completed',
              selected: current == FilterType.completed,
              onTap: () => onSelect(FilterType.completed)),
        ],
      ),
    );
  }
}

class _FilterOption extends StatefulWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterOption({required this.label, required this.selected, required this.onTap});
  @override
  State<_FilterOption> createState() => _FilterOptionState();
}

class _FilterOptionState extends State<_FilterOption> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          decoration: BoxDecoration(
            color: widget.selected ? kTeal.withOpacity(0.3) : kCardBg,
            border: Border.all(
                color: widget.selected ? kTeal : Colors.transparent,
                width: 1.5),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Text(widget.label, style: TextStyle(
                  color: kTextWhite, fontSize: 14,
                  fontWeight: widget.selected
                      ? FontWeight.w600 : FontWeight.w500)),
              const Spacer(),
              Container(
                width: 20, height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: widget.selected
                        ? Colors.white.withOpacity(0.7)
                        : Colors.white.withOpacity(0.25),
                    width: 2,
                  ),
                ),
                child: widget.selected ? Center(child: Container(
                  width: 9, height: 9,
                  decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                )) : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  TRIP DETAIL PAGE
// ══════════════════════════════════════════
class TripDetailPage extends StatefulWidget {
  final TripModel trip;
  const TripDetailPage({super.key, required this.trip});
  @override
  State<TripDetailPage> createState() => _TripDetailPageState();
}

class _TripDetailPageState extends State<TripDetailPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _routeAnim;
  late final Animation<double> _progressAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600));
    _routeAnim = CurvedAnimation(parent: _ctrl,
        curve: const Interval(0.1, 0.8, curve: Curves.easeOutCubic));
    _progressAnim = CurvedAnimation(parent: _ctrl,
        curve: const Interval(0.3, 0.9, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Animation<double> _itemAnim(double start) => CurvedAnimation(
    parent: _ctrl,
    curve: Interval(start, (start + 0.35).clamp(0.0, 1.0),
        curve: Curves.easeOutCubic),
  );

  @override
  Widget build(BuildContext context) {
    final trip = widget.trip;
    return Scaffold(
      backgroundColor: kDetailBg,
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 200,
              child: Stack(
                children: [
                  Container(
                    color: const Color(0xFF0D2133),
                    child: CustomPaint(
                        painter: _MapGridPainter(),
                        child: const SizedBox.expand()),
                  ),
                  AnimatedBuilder(
                    animation: _routeAnim,
                    builder: (_, __) => CustomPaint(
                        painter: _RoutePainter(progress: _routeAnim.value),
                        child: const SizedBox.expand()),
                  ),
                  _AnimPin(anim: _itemAnim(0.4), color: kTeal, left: 0.18, top: 0.60),
                  _AnimPin(anim: _itemAnim(0.72), color: kOrange, left: 0.75, top: 0.30),
                  Positioned(
                    top: 14, left: 14,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            shape: BoxShape.circle),
                        child: const Icon(Icons.arrow_back_rounded,
                            color: kTextWhite, size: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
                physics: const BouncingScrollPhysics(),
                children: [
                  _FadeSlide(
                    anim: _itemAnim(0.15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Trip #${trip.id}', style: const TextStyle(
                                color: kTextWhite, fontSize: 18,
                                fontWeight: FontWeight.w700)),
                            const SizedBox(height: 3),
                            Text(trip.date, style: const TextStyle(
                                color: kTextGrey, fontSize: 12)),
                          ],
                        ),
                        _StatusBadge(status: trip.status),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  _FadeSlide(
                    anim: _itemAnim(0.25),
                    child: Row(children: [
                      _InfoCard(value: '${trip.miles}', label: 'Miles'),
                      const SizedBox(width: 10),
                      _InfoCard(
                          value: '${((trip.progress ?? 0) * 100).round()}%',
                          label: 'Progress'),
                      const SizedBox(width: 10),
                      const _InfoCard(value: '~3h', label: 'ETA'),
                    ]),
                  ),
                  const SizedBox(height: 18),
                  _FadeSlide(
                    anim: _itemAnim(0.32),
                    child: Column(children: [
                      AnimatedBuilder(
                        animation: _progressAnim,
                        builder: (_, __) => ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: (trip.progress ?? 0) * _progressAnim.value,
                            minHeight: 8,
                            backgroundColor: const Color(0xFF1B3A52),
                            valueColor: const AlwaysStoppedAnimation<Color>(kTeal),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('0 mi',
                              style: TextStyle(color: kTextGrey, fontSize: 11)),
                          Text('${trip.miles} mi',
                              style: const TextStyle(color: kTextGrey, fontSize: 11)),
                        ],
                      ),
                    ]),
                  ),
                  const SizedBox(height: 16),
                  _FadeSlide(anim: _itemAnim(0.38), child: const _HDivider()),
                  const SizedBox(height: 14),
                  _FadeSlide(
                    anim: _itemAnim(0.44),
                    child: Column(children: [
                      _DetailRow(label: 'From', value: trip.from),
                      _DetailRow(label: 'To', value: trip.to),
                      const _DetailRow(label: 'Driver', value: 'Ahmed Hassan'),
                      const _DetailRow(label: 'Vehicle', value: 'Toyota Hilux · TRK-041'),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  _FadeSlide(anim: _itemAnim(0.52), child: const _HDivider()),
                  const SizedBox(height: 14),
                  _FadeSlide(
                    anim: _itemAnim(0.58),
                    child: const Column(children: [
                      _DetailRow(label: 'Departed', value: '08:30 AM'),
                      _DetailRow(label: 'Est. Arrival', value: '11:45 AM'),
                    ]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
//  REUSABLE WIDGETS
// ══════════════════════════════════════════
class _FadeSlide extends StatelessWidget {
  final Animation<double> anim;
  final Widget child;
  const _FadeSlide({required this.anim, required this.child});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: anim,
    builder: (_, __) => Opacity(
      opacity: anim.value,
      child: Transform.translate(
          offset: Offset(0, 16 * (1 - anim.value)), child: child),
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final String value;
  final String label;
  const _InfoCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
          color: kCardBg, borderRadius: BorderRadius.circular(12)),
      child: Column(children: [
        Text(value, style: const TextStyle(
            color: kTextWhite, fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: kTextGrey, fontSize: 10)),
      ]),
    ),
  );
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: kTextGrey, fontSize: 12)),
        Text(value, style: const TextStyle(
            color: kTextWhite, fontSize: 13, fontWeight: FontWeight.w500)),
      ],
    ),
  );
}

class _HDivider extends StatelessWidget {
  const _HDivider();
  @override
  Widget build(BuildContext context) =>
      Container(height: 1, color: Colors.white.withOpacity(0.06));
}

class _AnimPin extends StatelessWidget {
  final Animation<double> anim;
  final Color color;
  final double left;
  final double top;
  const _AnimPin({required this.anim, required this.color,
    required this.left, required this.top});

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (_, constraints) {
      final x = constraints.maxWidth * left;
      final y = constraints.maxHeight * top;
      return AnimatedBuilder(
        animation: anim,
        builder: (_, __) => Positioned(
          left: x - 5, top: y - 5,
          child: Opacity(
            opacity: anim.value,
            child: Transform.scale(
              scale: anim.value,
              child: Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                    color: color, shape: BoxShape.circle,
                    border: Border.all(color: kDetailBg, width: 2)),
              ),
            ),
          ),
        ),
      );
    },
  );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(color: kTextGrey, fontSize: 12.5,
          fontWeight: FontWeight.w500));
}

class _Dot extends StatelessWidget {
  final Color color;
  const _Dot({required this.color});
  @override
  Widget build(BuildContext context) => Container(
      width: 8, height: 8,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

// ══════════════════════════════════════════
//  PAINTERS
// ══════════════════════════════════════════
class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = const Color(0xFF00D5BE).withOpacity(0.05)
      ..strokeWidth = 1;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    for (double y = 0; y < size.height; y += step)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    final roadPaint = Paint()
      ..color = const Color(0xFF00D5BE).withOpacity(0.12)
      ..strokeWidth = 3;
    canvas.drawLine(Offset(0, size.height * 0.35),
        Offset(size.width, size.height * 0.35), roadPaint);
    canvas.drawLine(Offset(0, size.height * 0.60),
        Offset(size.width, size.height * 0.60), roadPaint);
    canvas.drawLine(Offset(size.width * 0.30, 0),
        Offset(size.width * 0.30, size.height), roadPaint);
    canvas.drawLine(Offset(size.width * 0.65, 0),
        Offset(size.width * 0.65, size.height), roadPaint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _RoutePainter extends CustomPainter {
  final double progress;
  const _RoutePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width * 0.18, size.height * 0.60)
      ..cubicTo(size.width * 0.35, size.height * 0.60,
          size.width * 0.40, size.height * 0.30,
          size.width * 0.55, size.height * 0.30)
      ..cubicTo(size.width * 0.65, size.height * 0.30,
          size.width * 0.70, size.height * 0.50,
          size.width * 0.75, size.height * 0.30);

    final metrics = path.computeMetrics().first;
    final drawn = metrics.extractPath(0, metrics.length * progress);
    canvas.drawPath(drawn, Paint()
      ..color = kTeal
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2));
  }
  @override
  bool shouldRepaint(_RoutePainter old) => old.progress != progress;
}