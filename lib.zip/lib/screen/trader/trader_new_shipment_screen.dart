import 'package:flutter/material.dart';
import '/screen/trader/trader_shipment_scheduled.dart';

class TraderNewShipmentScreen extends StatefulWidget {
  const TraderNewShipmentScreen({super.key});

  @override
  State<TraderNewShipmentScreen> createState() =>
      _TraderNewShipmentScreenState();
}

class _TraderNewShipmentScreenState extends State<TraderNewShipmentScreen> {
  final _pickupCtrl  = TextEditingController();
  final _dropoffCtrl = TextEditingController();
  final _packageCtrl = TextEditingController(text: '1');
  final _weightCtrl  = TextEditingController(text: '11');
  final _tempMinCtrl = TextEditingController(text: '2');
  final _tempMaxCtrl = TextEditingController(text: '8');

  bool _fragile      = false;
  bool _refrigerated = false;
  bool _filled       = false;

  String _selectedDate = '';
  String _selectedTime = '';

  static const String _distance = '142 miles';
  static const String _estTime  = '3h 25min';
  static const String _cost     = '\$240 - \$480';

  @override
  void dispose() {
    _pickupCtrl.dispose();
    _dropoffCtrl.dispose();
    _packageCtrl.dispose();
    _weightCtrl.dispose();
    _tempMinCtrl.dispose();
    _tempMaxCtrl.dispose();
    super.dispose();
  }

  void _checkFilled() {
    setState(() {
      _filled = _pickupCtrl.text.trim().isNotEmpty &&
          _dropoffCtrl.text.trim().isNotEmpty &&
          _selectedDate.isNotEmpty &&
          _selectedTime.isNotEmpty;
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(
            primary: Color(0xFF00D5BE),
            onPrimary: Colors.white,
            surface: Color(0xFF0A1628),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      _selectedDate =
          '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
      _checkFilled();
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(
            primary: Color(0xFF00D5BE),
            onPrimary: Colors.white,
            surface: Color(0xFF0A1628),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      _selectedTime =
          '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
      _checkFilled();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF1C3449),
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A1628).withOpacity(0.6),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: const Color(0xFF00D5BE).withOpacity(0.3),
                            width: 1),
                      ),
                      child: const Icon(Icons.arrow_back,
                          color: Color(0xFF00D5BE), size: 20),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Create Shipment',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      Text('Set up your delivery details',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.4),
                              fontSize: 13)),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    // ── Step 1: Route Setup ──
                    _stepHeader('1', 'Route Setup'),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A1628).withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: const Color(0xFF00D5BE).withOpacity(0.2),
                            width: 0.8),
                      ),
                      child: Column(
                        children: [
                          _locationField(
                            iconColor: const Color(0xFF00D5BE),
                            label: 'Pickup Location',
                            controller: _pickupCtrl,
                          ),
                          Divider(
                              color: const Color(0xFF00D5BE).withOpacity(0.2),
                              height: 1),
                          _locationField(
                            iconColor: const Color(0xFF0E8FD4),
                            label: 'Drop-off Location',
                            controller: _dropoffCtrl,
                          ),
                          Divider(
                              color: const Color(0xFF00D5BE).withOpacity(0.2),
                              height: 1),
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Date',
                                          style: TextStyle(
                                              color: Colors.white.withOpacity(0.4),
                                              fontSize: 12)),
                                      const SizedBox(height: 6),
                                      GestureDetector(
                                        onTap: _pickDate,
                                        child: Container(
                                          height: 36,
                                          padding: const EdgeInsets.symmetric(horizontal: 12),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF0A1628).withOpacity(0.5),
                                            borderRadius: BorderRadius.circular(14),
                                          ),
                                          child: Row(children: [
                                            const Icon(Icons.calendar_month_outlined,
                                                color: Color(0xFF00D5BE), size: 14),
                                            const SizedBox(width: 6),
                                            Text(
                                              _selectedDate.isEmpty ? 'Select' : _selectedDate,
                                              style: TextStyle(
                                                  color: _selectedDate.isEmpty
                                                      ? Colors.white.withOpacity(0.3)
                                                      : Colors.white,
                                                  fontSize: 12),
                                            ),
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Time',
                                          style: TextStyle(
                                              color: Colors.white.withOpacity(0.4),
                                              fontSize: 12)),
                                      const SizedBox(height: 6),
                                      GestureDetector(
                                        onTap: _pickTime,
                                        child: Container(
                                          height: 36,
                                          padding: const EdgeInsets.symmetric(horizontal: 12),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF0A1628).withOpacity(0.5),
                                            borderRadius: BorderRadius.circular(14),
                                          ),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            _selectedTime.isEmpty ? 'Select' : _selectedTime,
                                            style: TextStyle(
                                                color: _selectedTime.isEmpty
                                                    ? Colors.white.withOpacity(0.3)
                                                    : Colors.white,
                                                fontSize: 12),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ── Step 2: Shipment Details ──
                    _stepHeader('2', 'Shipment Details'),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A1628).withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: const Color(0xFF00D5BE).withOpacity(0.2),
                            width: 0.8),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: _inputField('Package Count', _packageCtrl,
                                      Icons.widgets_outlined, TextInputType.number),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _inputField('Weight (Kg)', _weightCtrl,
                                      Icons.monitor_weight_outlined, TextInputType.number),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),

                            _toggleRow(
                              icon: Icons.widgets_outlined,
                              iconColor: const Color(0xFFE6A817),
                              bgColor: const Color(0xFFE6A817),
                              title: 'Fragile Items',
                              subtitle: 'Handle with care',
                              value: _fragile,
                              activeColor: const Color(0xFF00D5BE),
                              onChanged: (v) => setState(() => _fragile = v),
                            ),
                            const SizedBox(height: 12),

                            _toggleRow(
                              icon: Icons.thermostat_outlined,
                              iconColor: const Color(0xFF00D3F2),
                              bgColor: const Color(0xFF00D3F2),
                              title: 'Refrigerated',
                              subtitle: 'Temperature controlled',
                              value: _refrigerated,
                              activeColor: const Color(0xFF00D3F2),
                              onChanged: (v) => setState(() => _refrigerated = v),
                            ),

                            if (_refrigerated) ...[
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF00D3F2).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Temperature Range (°C)',
                                        style: TextStyle(
                                            color: Color(0xFF00D3F2), fontSize: 12)),
                                    const SizedBox(height: 12),
                                    Row(
                                      children: [
                                        Expanded(child: _tempField('Min', _tempMinCtrl)),
                                        const SizedBox(width: 12),
                                        Expanded(child: _tempField('Max', _tempMaxCtrl)),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ── Step 3: Cost & Time Preview ──
                    _stepHeader('3', 'Cost & Time Preview'),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A1628).withOpacity(0.6),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: const Color(0xFF00D5BE).withOpacity(0.2),
                            width: 0.8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Estimated values - final price after vehicle selection',
                            style: TextStyle(
                                color: const Color(0xFF00D5BE).withOpacity(0.8),
                                fontSize: 11),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              _previewCol('Distance', _filled ? _distance : '--'),
                              _previewCol('Time', _filled ? _estTime : '--'),
                              _previewCol('Cost', _filled ? _cost : '--'),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    _filled ? _activeButton() : _disabledButton(),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── helper widgets ───

  Widget _stepHeader(String number, String title) {
    return Row(
      children: [
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF00D5BE), width: 2),
          ),
          child: Center(
            child: Text(number,
                style: const TextStyle(
                    color: Color(0xFF00D5BE),
                    fontSize: 13,
                    fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(width: 10),
        Text(title,
            style: const TextStyle(
                color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _locationField({
    required Color iconColor,
    required String label,
    required TextEditingController controller,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFF00D5BE).withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.location_on_outlined, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4), fontSize: 12)),
                const SizedBox(height: 4),
                TextField(
                  controller: controller,
                  onChanged: (_) => _checkFilled(),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600),
                  decoration: InputDecoration.collapsed(
                    hintText: 'Enter location',
                    hintStyle: TextStyle(
                        color: Colors.white.withOpacity(0.25), fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right,
              color: Colors.white.withOpacity(0.3), size: 20),
        ],
      ),
    );
  }

  Widget _inputField(String label, TextEditingController ctrl,
      IconData icon, TextInputType type) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.4), fontSize: 12)),
        const SizedBox(height: 6),
        Container(
          height: 40,
          padding: const EdgeInsets.only(left: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF0A1628).withOpacity(0.5),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(children: [
            Icon(icon, color: const Color(0xFF00D5BE), size: 16),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: ctrl,
                keyboardType: type,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: const InputDecoration.collapsed(hintText: ''),
              ),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _tempField(String label, TextEditingController ctrl) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.4), fontSize: 11)),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF0A1628).withOpacity(0.5),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold),
            decoration: const InputDecoration.collapsed(hintText: '0'),
          ),
        ),
      ],
    );
  }

  Widget _toggleRow({
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required String title,
    required String subtitle,
    required bool value,
    required Color activeColor,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1628).withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                  color: bgColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600)),
                Text(subtitle,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4), fontSize: 12)),
              ],
            ),
          ]),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: Colors.white,
            activeTrackColor: activeColor,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.2),
          ),
        ],
      ),
    );
  }

  Widget _previewCol(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.4), fontSize: 12)),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(
                  color: value == '--'
                      ? Colors.white.withOpacity(0.3)
                      : Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _activeButton() {
    return Container(
      width: double.infinity,
      height: 52,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF17D4B4), Color(0xFF0E8FD4)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF00D5BE).withOpacity(0.3),
              blurRadius: 16,
              offset: const Offset(0, 6)),
        ],
      ),
      child: ElevatedButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => TraderShipmentScheduled(
              pickup: _pickupCtrl.text.trim(),
              dropoff: _dropoffCtrl.text.trim(),
              date: _selectedDate,
              time: _selectedTime,
              packages: _packageCtrl.text.trim(),
              weight: _weightCtrl.text.trim(),
            ),
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: const Text('Choose Vehicle',
            style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _disabledButton() {
    return Container(
      width: double.infinity,
      height: 52,
      decoration: BoxDecoration(
        color: const Color(0xFF00D5BE).withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: const Color(0xFF00D5BE).withOpacity(0.15), width: 0.8),
      ),
      child: ElevatedButton(
        onPressed: null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          disabledBackgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: Text('Choose Vehicle',
            style: TextStyle(
                color: Colors.white.withOpacity(0.3),
                fontSize: 16,
                fontWeight: FontWeight.bold)),
      ),
    );
  }
}