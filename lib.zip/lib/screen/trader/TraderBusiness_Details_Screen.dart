import 'package:flutter/material.dart';
import '/screen/trader/TraderReviewConfirmScreen.dart';

class TraderBusinessDetailsScreen extends StatefulWidget {
  final String fullName;
  final String phone;
  final String email;
  final String nationalId;
  final String password;

  const TraderBusinessDetailsScreen({
    super.key,
    this.fullName = '',
    this.phone = '',
    this.email = '',
    this.nationalId = '',
    this.password = '',
  });

  @override
  State<TraderBusinessDetailsScreen> createState() =>
      _TraderBusinessDetailsScreenState();
}

class _TraderBusinessDetailsScreenState
    extends State<TraderBusinessDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _businessNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  @override
  void dispose() {
    _businessNameController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  void _handleNext() {
    if (_formKey.currentState!.validate()) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => TraderReviewConfirmScreen(
            fullName: widget.fullName,
            phone: widget.phone,
            email: widget.email,
            nationalId: widget.nationalId,
            password: widget.password,
            businessName: _businessNameController.text,
            address: _addressController.text,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001A2C),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                borderRadius: BorderRadius.circular(45),
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1.2,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            width: 45,
                            height: 45,
                            decoration: BoxDecoration(
                              color: const Color(0xFF132D3E).withOpacity(0.6),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.arrow_back,
                              color: Color(0xFF00D1D1),
                              size: 22,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        'Create Account',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Trader Registration',
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF6B8A9E),
                        ),
                      ),
                      const SizedBox(height: 40),
                      const _TraderStepperStep2(),
                      const SizedBox(height: 40),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 25,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF011624),
                          borderRadius: BorderRadius.circular(35),
                          border: Border.all(
                            color: const Color(0xFF00D1D1).withOpacity(0.1),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Center(
                              child: Text(
                                'Business Details',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 30),
                            _InputField(
                              label: 'Business Name',
                              hint: 'Enter your business name',
                              icon: Icons.business_outlined,
                              controller: _businessNameController,
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter business name';
                                }
                                return null;
                              },
                            ),
                            _InputField(
                              label: 'Address',
                              hint: 'Enter business address',
                              icon: Icons.location_on_outlined,
                              controller: _addressController,
                              validator: (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'Please enter address';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            _buildNextButton(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text(
                        '© 2025 TruckMate',
                        style: TextStyle(
                          color: Color(0xFF6B8A9E),
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNextButton() {
    return Container(
      width: double.infinity,
      height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF009EA3), Color(0xFF00D1D1)],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00D1D1).withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: _handleNext,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: const Text(
          'Next',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _InputField extends StatelessWidget {
  final String label;
  final String hint;
  final IconData icon;
  final TextEditingController controller;
  final String? Function(String?)? validator;

  const _InputField({
    required this.label,
    required this.hint,
    required this.icon,
    required this.controller,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: controller,
            validator: validator,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: Color(0xFF6B8A9E),
                fontSize: 14,
              ),
              prefixIcon: Icon(icon, color: const Color(0xFF00D1D1), size: 22),
              filled: true,
              fillColor: const Color(0xFF001A2C).withOpacity(0.6),
              errorStyle: const TextStyle(color: Colors.redAccent),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.05)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                  color: Color(0xFF00D1D1),
                  width: 1,
                ),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent, width: 1),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                  color: Colors.redAccent,
                  width: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TraderStepperStep2 extends StatelessWidget {
  const _TraderStepperStep2();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildStep(Icons.person, true),
        _buildLine(true),
        _buildStep(Icons.business_center_outlined, true),
        _buildLine(false),
        _buildStep(Icons.check_circle_outline, false),
      ],
    );
  }

  Widget _buildStep(IconData icon, bool isActive) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? Colors.transparent : const Color(0xFF132D3E),
        border: Border.all(
          color: isActive ? const Color(0xFF00D1D1) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Icon(
        icon,
        color: isActive ? const Color(0xFF00D1D1) : const Color(0xFF6B8A9E),
        size: 26,
      ),
    );
  }

  Widget _buildLine(bool isActive) {
    return Container(
      width: 45,
      height: 1.2,
      color: isActive ? const Color(0xFF00D1D1) : const Color(0xFF132D3E),
    );
  }
}