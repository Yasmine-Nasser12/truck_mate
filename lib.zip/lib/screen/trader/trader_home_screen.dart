import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import '/providers/user_provider.dart';
import '/models/trader_models.dart';
import '/data/trader_dummy_data.dart';
import '/screen/trader/trader_ui.dart';
import '/screen/trader/trader_new_shipment_screen.dart';
import '/screen/trader/trader_rating_screen.dart';

class TraderHomeScreen extends StatefulWidget {
  const TraderHomeScreen({super.key});

  @override
  State<TraderHomeScreen> createState() => _TraderHomeScreenState();
}

class _TraderHomeScreenState extends State<TraderHomeScreen> {
  late List<Shipment> _shipments;
  late List<DriverOffer> _offers;
  late List<TraderNotification> _notifications;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _shipments     = TraderDummyData.shipments();
    _offers        = TraderDummyData.offers(_shipments);
    _notifications = TraderDummyData.notifications();
  }

  void _acceptOffer(DriverOffer offer) {
    setState(() {
      _offers = _offers.map((item) => item.id == offer.id
          ? DriverOffer(
              id: item.id,
              shipmentId: item.shipmentId,
              driverName: item.driverName,
              rating: item.rating,
              completedTrips: item.completedTrips,
              price: item.price,
              etaHours: item.etaHours,
              vehicleType: item.vehicleType,
              status: OfferStatus.accepted,
              note: item.note,
            )
          : item).toList();
    });
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF152232),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Logout', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text('Are you sure you want to logout?', style: TextStyle(color: Color(0xFF6B8A9E))),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF6B8A9E))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Logout', style: TextStyle(color: Color(0xFF00D5BE), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', false);
      await prefs.remove('role');
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>();
    final displayName = user.fullName.isNotEmpty ? user.fullName : 'Trader';

    final summary = TraderDummyData.summary(_shipments, _offers);
    final featuredShipment = _shipments.firstWhere(
      (s) => s.isActive,
      orElse: () => _shipments.first,
    );

    final pages = [
      _DashboardPage(
        displayName: displayName,
        summary: summary,
        featuredShipment: featuredShipment,
        recentShipments: _shipments.take(5).toList(),
        onOpenShipments: () => setState(() => _currentIndex = 1),
        onOpenOffers:    () => setState(() => _currentIndex = 2),
        onShowShipment:  _showShipmentDetails,
        onCreateShipment: _openCreateShipment,
        onLogout: _logout,
      ),
      _ShipmentsPage(
        shipments: _shipments,
        onBack: () => setState(() => _currentIndex = 0),
        onShowDetails: _showShipmentDetails,
      ),
      _OffersPage(
        featuredShipment: featuredShipment,
        offers: _offers,
        onBack: () => setState(() => _currentIndex = 0),
        onAccept: _acceptOffer,
      ),
      _NotificationsPage(
        notifications: _notifications,
        onBack: () => setState(() => _currentIndex = 0),
      ),
    ];

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: traderBackground,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: pages[_currentIndex],
          ),
        ),
        bottomNavigationBar: _BottomNav(
          currentIndex: _currentIndex,
          onTap: (i) => setState(() => _currentIndex = i),
        ),
      ),
    );
  }

  Future<void> _showShipmentDetails(Shipment shipment) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _ShipmentDetailsScreen(
          shipment: shipment,
          onCancel: () {
            Navigator.pop(context);
            setState(() => _currentIndex = 1);
          },
        ),
      ),
    );
  }

  Future<void> _openCreateShipment() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const TraderNewShipmentScreen()),
    );
  }
}

// ═══════════════════════════════════════════════
// Bottom Nav
// ═══════════════════════════════════════════════
class _BottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  const _BottomNav({required this.currentIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: traderSurface,
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.07))),
      ),
      child: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: onTap,
        backgroundColor: Colors.transparent,
        elevation: 0,
        selectedItemColor: traderAccent,
        unselectedItemColor: traderTextMuted,
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory_2_outlined), label: 'Shipments'),
          BottomNavigationBarItem(icon: Icon(Icons.handshake_outlined), label: 'Offers'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_none), label: 'Alerts'),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════
// Dashboard Page
// ═══════════════════════════════════════════════
class _DashboardPage extends StatelessWidget {
  const _DashboardPage({
    required this.displayName,
    required this.summary,
    required this.featuredShipment,
    required this.recentShipments,
    required this.onOpenShipments,
    required this.onOpenOffers,
    required this.onShowShipment,
    required this.onCreateShipment,
    required this.onLogout,
  });

  final String displayName;
  final TraderSummary summary;
  final Shipment featuredShipment;
  final List<Shipment> recentShipments;
  final VoidCallback onOpenShipments;
  final VoidCallback onOpenOffers;
  final ValueChanged<Shipment> onShowShipment;
  final VoidCallback onCreateShipment;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    // Greeting based on time
    final hour = DateTime.now().hour;
    final greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
    final initial = displayName.isNotEmpty ? displayName[0].toUpperCase() : 'T';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(greeting,
                      style: const TextStyle(color: traderTextMuted, fontSize: 12)),
                  const SizedBox(height: 2),
                  Text(displayName,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 26, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            // Notification bell
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                      color: traderSurfaceDeep,
                      borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.notifications_none, color: Colors.white, size: 20),
                ),
                Positioned(
                  top: 6, right: 6,
                  child: Container(
                    width: 7, height: 7,
                    decoration: const BoxDecoration(
                        color: Color(0xFFFF476D), shape: BoxShape.circle),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 10),
            // Avatar
            CircleAvatar(
              radius: 18,
              backgroundColor: traderAccent,
              child: Text(initial,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
            ),
            const SizedBox(width: 10),
            // Logout button
            GestureDetector(
              onTap: onLogout,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: const Color(0xFF1A0A0A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFFF476D).withOpacity(0.4)),
                ),
                child: const Icon(Icons.logout, color: Color(0xFFFF476D), size: 18),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),

        // Hero tracking card
        GestureDetector(
          onTap: () => onShowShipment(featuredShipment),
          child: _HeroCard(shipment: featuredShipment),
        ),
        const SizedBox(height: 18),

        // Shipment Details section
        const Text('SHIPMENT DETAILS',
            style: TextStyle(
                color: traderTextMuted, fontSize: 10, letterSpacing: 1.4)),
        const SizedBox(height: 12),

        // Progress
        Row(
          children: [
            const Text('Progress',
                style: TextStyle(color: traderTextMuted, fontSize: 13)),
            const Spacer(),
            Text('${(featuredShipment.progress * 100).round()}%',
                style: const TextStyle(
                    color: traderAccent, fontSize: 13, fontWeight: FontWeight.w700)),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: featuredShipment.progress,
            minHeight: 5,
            backgroundColor: Colors.white12,
            valueColor: const AlwaysStoppedAnimation<Color>(traderAccent),
          ),
        ),
        const SizedBox(height: 14),

        // Driver row
        Row(
          children: [
            const Text('Driver',
                style: TextStyle(color: traderTextMuted, fontSize: 13)),
            const SizedBox(width: 16),
            CircleAvatar(
              radius: 10,
              backgroundColor: traderAccent,
              child: Text(
                featuredShipment.driverName.split(' ').map((p) => p[0]).take(2).join(),
                style: const TextStyle(fontSize: 7, color: Colors.white),
              ),
            ),
            const SizedBox(width: 8),
            Text(featuredShipment.driverName,
                style: const TextStyle(color: Colors.white, fontSize: 13)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(
                  color: const Color(0xFF3A3B2B),
                  borderRadius: BorderRadius.circular(10)),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.star, color: Color(0xFFF4C14B), size: 10),
                  SizedBox(width: 3),
                  Text('4.8',
                      style: TextStyle(color: Color(0xFFF4C14B), fontSize: 10)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Shipment ID row
        Row(
          children: [
            const Text('Shipment ID',
                style: TextStyle(color: traderTextMuted, fontSize: 13)),
            const Spacer(),
            Text(featuredShipment.reference,
                style: const TextStyle(
                    color: traderAccent, fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 18),

        // Create New Shipment card
        GestureDetector(
          onTap: onCreateShipment,
          child: TraderPanel(
            radius: 16,
            child: Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: traderAccent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.location_on_outlined,
                      color: Colors.white, size: 24),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Create New\nShipment',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 17,
                              height: 1.2)),
                      SizedBox(height: 4),
                      Text('Get instant driver matches',
                          style: TextStyle(color: traderTextMuted, fontSize: 11)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_rounded,
                    color: traderAccent, size: 20),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Recent Activity
        Row(
          children: [
            const Text('RECENT ACTIVITY',
                style: TextStyle(
                    color: traderTextMuted, fontSize: 10, letterSpacing: 1.3)),
            const Spacer(),
            GestureDetector(
              onTap: onOpenShipments,
              child: const Text('View All',
                  style: TextStyle(color: traderAccent, fontSize: 13)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...recentShipments.map((s) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _RecentActivityTile(shipment: s, onTap: () => onShowShipment(s)),
            )),
        const SizedBox(height: 4),
      ],
    );
  }
}

// ═══════════════════════════════════════════════
// Hero Card (map-style tracking)
// ═══════════════════════════════════════════════
class _HeroCard extends StatelessWidget {
  final Shipment shipment;
  const _HeroCard({required this.shipment});

  @override
  Widget build(BuildContext context) {
    return TraderPanel(
      radius: 18,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      child: Column(
        children: [
          Row(
            children: [
              StatusPill(
                label: shipmentStatusLabel(shipment.status).toUpperCase(),
                color: shipmentStatusColor(shipment.status),
              ),
              const Spacer(),
              StatusPill(
                label: '${shipment.origin}  →  ${shipment.destination}',
                color: traderAccentSoft,
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Map area
          Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF0A2A45), Color(0xFF123E4E)],
              ),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(painter: _RoutePainter()),
                ),
                const Positioned(
                  left: 20, bottom: 30,
                  child: _RouteNode(active: false),
                ),
                Positioned(
                  right: 20, top: 20,
                  child: Column(
                    children: [
                      StatusPill(
                          label: shipment.destination, color: Colors.white),
                      const SizedBox(height: 8),
                      const _RouteNode(active: true),
                    ],
                  ),
                ),
                const Center(
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: Color(0xFF3A73FF),
                    child: Icon(Icons.navigation_rounded,
                        color: Colors.white, size: 16),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                    color: traderAccent,
                    borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.bolt, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ESTIMATED TIME',
                      style: TextStyle(color: traderTextMuted, fontSize: 9)),
                  Text('45 min',
                      style: TextStyle(
                          color: traderAccent,
                          fontSize: 18,
                          fontWeight: FontWeight.w700)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                    color: traderAccentSoft,
                    borderRadius: BorderRadius.circular(12)),
                child: const Text('View Live  →',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RouteNode extends StatelessWidget {
  final bool active;
  const _RouteNode({required this.active});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: active ? 16 : 12,
      height: active ? 16 : 12,
      decoration: BoxDecoration(
        color: active ? traderAccent : Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: traderAccent, width: 2),
        boxShadow: active
            ? [BoxShadow(color: traderAccent.withOpacity(0.45), blurRadius: 10)]
            : null,
      ),
    );
  }
}

class _RoutePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = traderAccent
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(24, size.height - 36)
      ..quadraticBezierTo(
          size.width * 0.45, size.height * 0.55, size.width - 26, 28);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════
// Shipments Page
// ═══════════════════════════════════════════════
class _ShipmentsPage extends StatefulWidget {
  final List<Shipment> shipments;
  final VoidCallback onBack;
  final ValueChanged<Shipment> onShowDetails;
  const _ShipmentsPage({
    required this.shipments,
    required this.onBack,
    required this.onShowDetails,
  });

  @override
  State<_ShipmentsPage> createState() => _ShipmentsPageState();
}

class _ShipmentsPageState extends State<_ShipmentsPage> {
  int _page = 0;
  static const int _pageSize = 6;

  @override
  Widget build(BuildContext context) {
    final totalPages =
        (widget.shipments.length / _pageSize).ceil().clamp(1, 999);
    final pageItems =
        widget.shipments.skip(_page * _pageSize).take(_pageSize).toList();
    final totalSpent =
        pageItems.fold<double>(0, (sum, s) => sum + s.price) / 1000;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ScreenTopBar(
          title: 'My Shipments',
          subtitle: '${widget.shipments.length} total shipments',
          leading: TraderIconButton(
              icon: Icons.arrow_back_ios_new_rounded, onTap: widget.onBack),
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            const Expanded(
              child: MetricMiniCard(
                icon: Icons.calendar_today_outlined,
                label: 'This Month',
                value: '12',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: MetricMiniCard(
                icon: Icons.attach_money_rounded,
                label: 'Total Spent',
                value: '\$${totalSpent.toStringAsFixed(1)}K',
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        ...pageItems.map((s) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _ShipmentListTile(
                  shipment: s, onTap: () => widget.onShowDetails(s)),
            )),
        const SizedBox(height: 8),
        _Pager(
          page: _page,
          totalPages: totalPages,
          onPrevious: _page == 0 ? null : () => setState(() => _page--),
          onNext: _page >= totalPages - 1 ? null : () => setState(() => _page++),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════
// Offers Page
// ═══════════════════════════════════════════════
class _OffersPage extends StatefulWidget {
  final Shipment featuredShipment;
  final List<DriverOffer> offers;
  final VoidCallback onBack;
  final ValueChanged<DriverOffer> onAccept;
  const _OffersPage({
    required this.featuredShipment,
    required this.offers,
    required this.onBack,
    required this.onAccept,
  });

  @override
  State<_OffersPage> createState() => _OffersPageState();
}

class _OffersPageState extends State<_OffersPage> {
  int _page = 0;
  static const int _pageSize = 4;

  @override
  Widget build(BuildContext context) {
    final totalPages =
        (widget.offers.length / _pageSize).ceil().clamp(1, 999);
    final pageItems =
        widget.offers.skip(_page * _pageSize).take(_pageSize).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ScreenTopBar(
          title: 'Driver Offers',
          subtitle: '${widget.offers.length} drivers available',
          leading: TraderIconButton(
              icon: Icons.arrow_back_ios_new_rounded, onTap: widget.onBack),
        ),
        const SizedBox(height: 18),
        TraderPanel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Your Shipment',
                  style: TextStyle(color: traderTextMuted, fontSize: 11)),
              const SizedBox(height: 6),
              Text(
                '${widget.featuredShipment.origin}  →  ${widget.featuredShipment.destination}',
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 15),
              ),
              const SizedBox(height: 4),
              Text(
                '${widget.featuredShipment.weightTons.toStringAsFixed(1)} tons  ·  ${widget.featuredShipment.vehicleInfo}',
                style:
                    const TextStyle(color: traderTextMuted, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        ...pageItems.map((offer) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _OfferListTile(
                  offer: offer, onAccept: () => widget.onAccept(offer)),
            )),
        _Pager(
          page: _page,
          totalPages: totalPages,
          onPrevious: _page == 0 ? null : () => setState(() => _page--),
          onNext: _page >= totalPages - 1 ? null : () => setState(() => _page++),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════
// Notifications Page
// ═══════════════════════════════════════════════
class _NotificationsPage extends StatelessWidget {
  final List<TraderNotification> notifications;
  final VoidCallback onBack;
  const _NotificationsPage(
      {required this.notifications, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ScreenTopBar(
          title: 'Alerts',
          subtitle: '${notifications.length} recent updates',
          leading: TraderIconButton(
              icon: Icons.arrow_back_ios_new_rounded, onTap: onBack),
        ),
        const SizedBox(height: 18),
        ...notifications.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: TraderPanel(
                radius: 14,
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: traderAccent.withOpacity(0.14),
                      child: Icon(notificationIcon(item.type),
                          color: traderAccent, size: 17),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.title,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13)),
                          const SizedBox(height: 4),
                          Text(item.subtitle,
                              style: const TextStyle(
                                  color: traderTextMuted, fontSize: 11)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(item.timeLabel,
                        style: const TextStyle(
                            color: traderAccent, fontSize: 11)),
                  ],
                ),
              ),
            )),
      ],
    );
  }
}

// ═══════════════════════════════════════════════
// Shipment Details Screen (full page)
// ═══════════════════════════════════════════════
class _ShipmentDetailsScreen extends StatelessWidget {
  final Shipment shipment;
  final VoidCallback onCancel;
  const _ShipmentDetailsScreen(
      {required this.shipment, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final eta = math.max((shipment.progress * 70).round(), 45);
    return Scaffold(
      backgroundColor: traderBackground,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            // Top bar
            Row(
              children: [
                TraderIconButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    onTap: () => Navigator.pop(context)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(shipment.reference,
                          style: const TextStyle(
                              color: traderTextMuted,
                              fontSize: 10,
                              letterSpacing: 1.1)),
                      const SizedBox(height: 3),
                      StatusPill(
                        label: shipmentStatusLabel(shipment.status),
                        color: shipmentStatusColor(shipment.status),
                      ),
                    ],
                  ),
                ),
                Text('ETA',
                    style: TextStyle(
                        color: traderTextMuted.withOpacity(0.7),
                        fontSize: 11)),
                const SizedBox(width: 6),
                Text('${eta}m',
                    style: const TextStyle(
                        color: traderAccent,
                        fontSize: 22,
                        fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 14),

            // Map card
            Container(
              height: 260,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF0B2237), Color(0xFF133A5A)],
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 20, left: 16,
                    child: Text(shipment.origin,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 10)),
                  ),
                  Positioned(
                    top: 40, right: 20,
                    child: Text(shipment.destination,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 10)),
                  ),
                  Positioned.fill(
                      child: CustomPaint(painter: _TrackingPainter())),
                  const Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: Color(0xFF3A73FF),
                      child: Icon(Icons.navigation_rounded,
                          color: Colors.white),
                    ),
                  ),
                  const Positioned(
                    top: 66, right: 36,
                    child: CircleAvatar(
                        radius: 11, backgroundColor: traderAccent),
                  ),
                  const Positioned(
                    left: 48, bottom: 80,
                    child: CircleAvatar(
                        radius: 8, backgroundColor: traderAccent),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),

            // Info panel
            TraderPanel(
              radius: 20,
              child: Column(
                children: [
                  // Handle
                  Container(
                    width: 48, height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(999)),
                  ),

                  // Driver row
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: traderAccent,
                        child: Text(
                          shipment.driverName
                              .split(' ')
                              .map((p) => p[0])
                              .take(2)
                              .join(),
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(shipment.driverName,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Text(
                                '4.8  ·  ${shipment.vehicleInfo}',
                                style: const TextStyle(
                                    color: traderTextMuted, fontSize: 12)),
                          ],
                        ),
                      ),
                      CircleAvatar(
                        radius: 18,
                        backgroundColor: traderAccent,
                        child: const Icon(Icons.phone_outlined,
                            color: Colors.white, size: 16),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Route / Weight / Price row
                  Row(
                    children: [
                      Expanded(
                          child: _InfoBox(
                              label: 'ROUTE',
                              value:
                                  '${shipment.origin} → ${shipment.destination}')),
                      const SizedBox(width: 8),
                      Expanded(
                          child: _InfoBox(
                              label: 'WEIGHT',
                              value:
                                  '${shipment.weightTons.toStringAsFixed(1)} tons')),
                      const SizedBox(width: 8),
                      Expanded(
                          child: _InfoBox(
                              label: 'PRICE',
                              value:
                                  '\$${shipment.price.toStringAsFixed(0)}')),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Timeline
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('STATUS TIMELINE',
                        style: TextStyle(
                            color: traderTextMuted,
                            fontSize: 10,
                            letterSpacing: 1.1)),
                  ),
                  const SizedBox(height: 12),
                  ...shipment.timeline.map((item) => _TimelineRow(item: item)),
                  const SizedBox(height: 12),

                  // Rate Driver (delivered) or Cancel Shipment
                  if (shipment.status == ShipmentStatus.delivered)
                    SizedBox(
                      width: double.infinity, height: 50,
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => RateDriverScreen(
                            driverName: shipment.driverName,
                            driverInitials: shipment.driverName
                                .split(' ').map((p) => p[0]).take(2).join(),
                          ))),
                        icon: const Icon(Icons.star_outline_rounded, size: 20),
                        label: const Text('Rate Driver',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00D5BE),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14))),
                      ),
                    )
                  else
                    SizedBox(
                      width: double.infinity, height: 50,
                      child: ElevatedButton(
                        onPressed: onCancel,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3D1525),
                          foregroundColor: const Color(0xFFFF7E8E),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        child: const Text('Cancel Shipment',
                            style: TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════
// Create Shipment Screen
// ═══════════════════════════════════════════════
class _CreateShipmentScreen extends StatefulWidget {
  const _CreateShipmentScreen();

  @override
  State<_CreateShipmentScreen> createState() => _CreateShipmentScreenState();
}

class _CreateShipmentScreenState extends State<_CreateShipmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _origin      = TextEditingController(text: 'Maadi');
  final _destination = TextEditingController(text: 'Nasr City');
  final _goods       = TextEditingController(text: 'Electronics');
  final _price       = TextEditingController(text: '285');
  final _weight      = TextEditingController(text: '2.5');

  @override
  void dispose() {
    _origin.dispose(); _destination.dispose();
    _goods.dispose(); _price.dispose(); _weight.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: traderBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ScreenTopBar(
                title: 'Create Shipment',
                subtitle: 'Fill in your shipment details',
                leading: TraderIconButton(
                    icon: Icons.arrow_back_ios_new_rounded,
                    onTap: () => Navigator.pop(context)),
              ),
              const SizedBox(height: 20),
              TraderPanel(
                radius: 20,
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _field(_origin, 'Origin', Icons.location_on_outlined),
                      const SizedBox(height: 12),
                      _field(_destination, 'Destination', Icons.flag_outlined),
                      const SizedBox(height: 12),
                      _field(_goods, 'Goods Type', Icons.inventory_2_outlined),
                      const SizedBox(height: 12),
                      _field(_price, 'Price (\$)', Icons.attach_money,
                          type: TextInputType.number),
                      const SizedBox(height: 12),
                      _field(_weight, 'Weight (tons)', Icons.scale_outlined,
                          type: TextInputType.number),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: traderAccent,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                          ),
                          child: const Text('Create Shipment',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w700)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label, IconData icon,
      {TextInputType type = TextInputType.text}) {
    return TextFormField(
      controller: ctrl,
      keyboardType: type,
      validator: (v) =>
          v == null || v.trim().isEmpty ? 'Required' : null,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: traderTextMuted),
        prefixIcon: Icon(icon, color: traderAccent, size: 20),
        filled: true,
        fillColor: traderSurfaceDeep,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      Shipment(
        id: 'SHP-${DateTime.now().millisecondsSinceEpoch}',
        title: '${_goods.text} Delivery',
        reference: 'TM-DEMO-${DateTime.now().second}',
        origin: _origin.text,
        destination: _destination.text,
        departureDate: '2026-03-11',
        price: double.tryParse(_price.text) ?? 0,
        weightTons: double.tryParse(_weight.text) ?? 0,
        status: ShipmentStatus.pending,
        progress: 0.2,
        driverName: 'Ahmed Hassan',
        vehicleInfo: 'Flatbed Truck',
        goodsType: _goods.text,
        priority: 'Standard',
        timeline: const [
          ShipmentMilestone(label: 'Picked Up', time: 'Current stage', isDone: true),
          ShipmentMilestone(label: 'In Transit', time: 'Current status', isDone: true),
          ShipmentMilestone(label: 'Delivered', time: 'Pending', isDone: false),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════
// Shared small widgets
// ═══════════════════════════════════════════════
class _RecentActivityTile extends StatelessWidget {
  final Shipment shipment;
  final VoidCallback onTap;
  const _RecentActivityTile({required this.shipment, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: TraderPanel(
        radius: 14,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        color: traderSurfaceDeep,
        child: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: traderAccent.withOpacity(0.16),
              child: const Icon(Icons.local_shipping_outlined,
                  color: traderAccent, size: 15),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${shipment.origin}  →  ${shipment.destination}',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(
                      '${shipment.departureDate.replaceAll('2026-', 'Jan ')}  ·  Delivered',
                      style: const TextStyle(
                          color: traderTextMuted, fontSize: 10)),
                ],
              ),
            ),
            Text('\$${shipment.price.toStringAsFixed(0)}',
                style: const TextStyle(
                    color: traderAccent,
                    fontSize: 13,
                    fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class _ShipmentListTile extends StatelessWidget {
  final Shipment shipment;
  final VoidCallback onTap;
  const _ShipmentListTile({required this.shipment, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: TraderPanel(
        radius: 16,
        padding: const EdgeInsets.all(14),
        color: traderSurfaceDeep,
        child: Column(
          children: [
            Row(
              children: [
                Text(
                    shipment.departureDate
                        .replaceAll('2026-01-', 'Jan ')
                        .replaceAll('-', '/'),
                    style: const TextStyle(
                        color: traderTextMuted, fontSize: 11)),
                const Spacer(),
                StatusPill(
                  label: shipmentStatusLabel(shipment.status),
                  color: shipmentStatusColor(shipment.status),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.circle, color: traderAccent, size: 7),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                      '${shipment.origin}  →  ${shipment.destination}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600)),
                ),
                Text('\$${shipment.price.toStringAsFixed(0)}',
                    style: const TextStyle(
                        color: traderAccent, fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Driver: ${shipment.driverName}',
                  style: const TextStyle(
                      color: traderTextMuted, fontSize: 11)),
            ),
          ],
        ),
      ),
    );
  }
}

class _OfferListTile extends StatelessWidget {
  final DriverOffer offer;
  final VoidCallback onAccept;
  const _OfferListTile({required this.offer, required this.onAccept});

  @override
  Widget build(BuildContext context) {
    return TraderPanel(
      radius: 16,
      color: traderSurfaceDeep,
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: traderAccentSoft,
                child: Text(
                  offer.driverName.split(' ').map((p) => p[0]).take(2).join(),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(offer.driverName,
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Text(offer.vehicleType,
                            style: const TextStyle(
                                color: traderTextMuted, fontSize: 11)),
                        const Text('  ·  ',
                            style: TextStyle(color: traderTextMuted)),
                        const Icon(Icons.star,
                            color: Color(0xFFF4C14B), size: 11),
                        const SizedBox(width: 2),
                        Text(offer.rating.toStringAsFixed(1),
                            style: const TextStyle(
                                color: traderTextMuted, fontSize: 11)),
                        const Text('  ·  ',
                            style: TextStyle(color: traderTextMuted)),
                        Text('${offer.completedTrips} trips',
                            style: const TextStyle(
                                color: traderTextMuted, fontSize: 11)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
                color: traderBackground,
                borderRadius: BorderRadius.circular(12)),
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Price',
                        style:
                            TextStyle(color: traderTextMuted, fontSize: 10)),
                    const SizedBox(height: 3),
                    Text('\$${offer.price.toStringAsFixed(0)}',
                        style: const TextStyle(
                            color: Color(0xFF31E19F),
                            fontSize: 22,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('Delivery',
                        style:
                            TextStyle(color: traderTextMuted, fontSize: 10)),
                    const SizedBox(height: 3),
                    Text('${offer.etaHours}-${offer.etaHours + 1} hrs',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                    color: const Color(0x44773A59),
                    borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.close_rounded,
                    color: Color(0xFFF26A88), size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton.icon(
                    onPressed: onAccept,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: traderAccentSoft,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    icon: const Icon(Icons.check, size: 16),
                    label: const Text('Accept',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoBox extends StatelessWidget {
  final String label;
  final String value;
  const _InfoBox({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return TraderPanel(
      radius: 12,
      padding: const EdgeInsets.all(10),
      color: traderSurfaceDeep,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: traderTextMuted, fontSize: 9)),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 11)),
        ],
      ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  final ShipmentMilestone item;
  const _TimelineRow({required this.item});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 22, height: 22,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: item.isDone ? traderAccent : Colors.white24,
                  width: 2),
            ),
            child: item.isDone
                ? const Icon(Icons.circle, size: 8, color: traderAccent)
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label,
                    style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 2),
                Text(item.time,
                    style: const TextStyle(
                        color: traderTextMuted, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Pager extends StatelessWidget {
  final int page;
  final int totalPages;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  const _Pager(
      {required this.page,
      required this.totalPages,
      required this.onPrevious,
      required this.onNext});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text('Page ${page + 1} / $totalPages',
            style: const TextStyle(color: traderTextMuted, fontSize: 11)),
        const Spacer(),
        TraderIconButton(
            icon: Icons.chevron_left_rounded, onTap: onPrevious),
        const SizedBox(width: 8),
        TraderIconButton(
            icon: Icons.chevron_right_rounded, onTap: onNext),
      ],
    );
  }
}

class _TrackingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = traderAccent
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(56, size.height - 88)
      ..quadraticBezierTo(
          size.width * 0.45, size.height * 0.55, size.width - 42, 74);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}