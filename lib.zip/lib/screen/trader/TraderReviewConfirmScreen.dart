import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/providers/user_provider.dart';
import '/screen/trader/trader_otp_screen.dart';

class TraderReviewConfirmScreen extends StatelessWidget {
  final String fullName;
  final String phone;
  final String email;
  final String nationalId;
  final String password;
  final String businessName;
  final String address;

  const TraderReviewConfirmScreen({
    super.key,
    this.fullName = '',
    this.phone = '',
    this.email = '',
    this.nationalId = '',
    this.password = '',
    this.businessName = '',
    this.address = '',
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF001A2C),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                borderRadius: BorderRadius.circular(45),
                border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.2),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                child: Column(
                  children: [
                    Align(alignment: Alignment.centerLeft, child: _buildBackButton(context)),
                    const SizedBox(height: 15),
                    const Text('Create Account', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                    const SizedBox(height: 8),
                    const Text('Trader Registration', style: TextStyle(fontSize: 16, color: Color(0xFF6B8A9E))),
                    const SizedBox(height: 40),
                    const TraderStepperReview(activeStep: 3),
                    const SizedBox(height: 40),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFF011624),
                        borderRadius: BorderRadius.circular(35),
                        border: Border.all(color: const Color(0xFF00D1D1).withOpacity(0.1)),
                      ),
                      child: Column(
                        children: [
                          const Text('Review & Confirm', style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 30),
                          _buildReviewSection(context: context, title: 'Personal Information',
                            data: {'Full Name': fullName, 'Phone': phone, 'Email': email, 'National ID': nationalId},
                            onEdit: () => Navigator.pop(context)),
                          const SizedBox(height: 20),
                          _buildReviewSection(context: context, title: 'Business Details',
                            data: {'Business Name': businessName, 'Address': address},
                            onEdit: () => Navigator.pop(context)),
                          const SizedBox(height: 30),
                          _buildCreateAccountButton(context),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    const Text('© 2025 TruckMate', style: TextStyle(color: Color(0xFF6B8A9E), fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildReviewSection({required BuildContext context, required String title, required Map<String, String> data, required VoidCallback onEdit}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF001A2C).withOpacity(0.5), borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(color: Color(0xFF6B8A9E), fontSize: 14)),
              GestureDetector(onTap: onEdit, child: const Icon(Icons.edit_outlined, color: Color(0xFF00D1D1), size: 18)),
            ],
          ),
          const SizedBox(height: 12),
          ...data.entries.map((entry) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(children: [
              Text('${entry.key} : ', style: const TextStyle(color: Colors.white70, fontSize: 13)),
              Expanded(child: Text(entry.value, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500), overflow: TextOverflow.ellipsis)),
            ]),
          )),
        ],
      ),
    );
  }

  Widget _buildCreateAccountButton(BuildContext context) {
    return Container(
      width: double.infinity, height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF009EA3), Color(0xFF00D1D1)]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: const Color(0xFF00D1D1).withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: ElevatedButton(
        onPressed: () {
          // ✅ Navigate to OTP
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => TraderOtpScreen(
              fullName:     fullName,
              phone:        phone,
              email:        email,
              nationalId:   nationalId,
              password:     password,
              businessName: businessName,
              address:      address,
            ),
          ));
        },
        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: const Text('Create Account', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
      ),
    );
  }

  Widget _buildBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: const BoxDecoration(color: Color(0xFF132D3E), shape: BoxShape.circle),
        child: const Icon(Icons.arrow_back, color: Color(0xFF00D1D1), size: 20),
      ),
    );
  }
}

class TraderStepperReview extends StatelessWidget {
  final int activeStep;
  const TraderStepperReview({super.key, required this.activeStep});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildStep(Icons.person, activeStep >= 1),
        _buildLine(activeStep >= 2),
        _buildStep(Icons.business_center_outlined, activeStep >= 2),
        _buildLine(activeStep >= 3),
        _buildStep(Icons.check_circle_outline, activeStep >= 3),
      ],
    );
  }

  Widget _buildStep(IconData icon, bool isActive) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? Colors.transparent : const Color(0xFF132D3E),
        border: Border.all(color: isActive ? const Color(0xFF00D1D1) : Colors.transparent, width: 1.5),
      ),
      child: Icon(icon, color: isActive ? const Color(0xFF00D1D1) : const Color(0xFF6B8A9E), size: 26),
    );
  }

  Widget _buildLine(bool isFinished) {
    return Container(width: 45, height: 1.2, color: isFinished ? const Color(0xFF00D1D1) : const Color(0xFF132D3E));
  }
}