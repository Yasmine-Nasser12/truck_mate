import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '/screen/trader/TraderBusiness_Details_Screen.dart';

const Color _kBg   = Color(0xFF001A2C);
const Color _kCard = Color(0xFF011624);
const Color _kTeal = Color(0xFF00D1D1);
const Color _kGrey = Color(0xFF6B8A9E);

class TraderRegistrationScreen extends StatefulWidget {
  const TraderRegistrationScreen({super.key});
  @override
  State<TraderRegistrationScreen> createState() => _TraderRegistrationScreenState();
}

class _TraderRegistrationScreenState extends State<TraderRegistrationScreen>
    with SingleTickerProviderStateMixin {
  final _formKey    = GlobalKey<FormState>();
  late AnimationController _bgCtrl;

  final _nameCtrl    = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _emailCtrl   = TextEditingController();
  final _idCtrl      = TextEditingController();
  final _passCtrl    = TextEditingController();
  final _confirmCtrl = TextEditingController();

  bool _obscurePass    = true;
  bool _obscureConfirm = true;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 15))..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _nameCtrl.dispose(); _phoneCtrl.dispose(); _emailCtrl.dispose();
    _idCtrl.dispose(); _passCtrl.dispose(); _confirmCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgCtrl,
              builder: (_, __) => CustomPaint(painter: _BgPainter(_bgCtrl.value)),
            ),
          ),
          Positioned.fill(child: Container(color: _kBg.withOpacity(0.75))),
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.01),
                    borderRadius: BorderRadius.circular(45),
                    border: Border.all(color: Colors.white.withOpacity(0.1), width: 1.2),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                width: 45, height: 45,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF132D3E).withOpacity(0.6),
                                  shape: BoxShape.circle,
                                  boxShadow: [BoxShadow(color: _kTeal.withOpacity(0.2), blurRadius: 15)],
                                ),
                                child: const Icon(Icons.arrow_back, color: _kTeal, size: 22),
                              ),
                            ),
                          ),
                          const SizedBox(height: 15),
                          const Text('Create Account', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                          const SizedBox(height: 8),
                          const Text('Trader Registration', style: TextStyle(fontSize: 16, color: _kGrey)),
                          const SizedBox(height: 40),
                          const _Stepper(step: 0),
                          const SizedBox(height: 40),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 25),
                            decoration: BoxDecoration(
                              color: _kCard,
                              borderRadius: BorderRadius.circular(35),
                              border: Border.all(color: _kTeal.withOpacity(0.1)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Center(child: Text('Personal Information',
                                    style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold))),
                                const SizedBox(height: 30),
                                _Field(label: 'Full Name',   hint: 'Enter your full name',    icon: Icons.person_outline,  ctrl: _nameCtrl,  type: TextInputType.name,
                                  validator: (v) => (v == null || v.isEmpty) ? 'Required' : null),
                                _Field(label: 'Phone',       hint: 'Enter your phone number', icon: Icons.phone_outlined,  ctrl: _phoneCtrl, type: TextInputType.phone,
                                  validator: (v) => (v?.length != 11) ? 'Must be 11 digits' : null),
                                _Field(label: 'Email',       hint: 'Enter your email',        icon: Icons.email_outlined,  ctrl: _emailCtrl, type: TextInputType.emailAddress,
                                  validator: (v) => (v == null || !v.contains('@')) ? 'Invalid email' : null),
                                _Field(label: 'National ID', hint: 'Enter national ID',       icon: Icons.badge_outlined,  ctrl: _idCtrl,    type: TextInputType.number,
                                  validator: (v) => (v?.length != 14) ? 'Must be 14 digits' : null),
                                _PassField(label: 'Password',         hint: 'Enter password',      ctrl: _passCtrl,    obscure: _obscurePass,
                                  onToggle: () => setState(() => _obscurePass = !_obscurePass),
                                  validator: (v) => (v == null || v.length < 6) ? 'Min 6 characters' : null),
                                _PassField(label: 'Confirm Password', hint: 'Re-enter password',   ctrl: _confirmCtrl, obscure: _obscureConfirm,
                                  onToggle: () => setState(() => _obscureConfirm = !_obscureConfirm),
                                  validator: (v) => (v != _passCtrl.text) ? 'Passwords do not match' : null),
                                const SizedBox(height: 10),
                                _NextBtn(onPressed: () async {
                                  if (_formKey.currentState!.validate()) {
                                    // ✅ تحقق إن الـ email مش مسجل كـ Driver
                                    final prefs = await SharedPreferences.getInstance();
                                    final registered = prefs.getStringList('registeredEmails') ?? [];
                                    final email = _emailCtrl.text.trim().toLowerCase();
                                    final isDriver = registered.any((e) => e == '${email}:driver');
                                    if (isDriver) {
                                      if (!context.mounted) return;
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content: Text('This email is already registered as a Driver!'),
                                          backgroundColor: Colors.redAccent,
                                        ),
                                      );
                                      return;
                                    }
                                    if (!context.mounted) return;
                                    Navigator.push(context, MaterialPageRoute(
                                      builder: (_) => TraderBusinessDetailsScreen(
                                        fullName: _nameCtrl.text, phone: _phoneCtrl.text,
                                        email: _emailCtrl.text,   nationalId: _idCtrl.text,
                                        password: _passCtrl.text,
                                      ),
                                    ));
                                  }
                                }),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          const Text('© 2025 TruckMate', style: TextStyle(color: _kGrey, fontSize: 14)),
                          const SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Stepper ──
class _Stepper extends StatelessWidget {
  final int step;
  const _Stepper({required this.step});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _dot(Icons.person_outline,       step >= 0),
        _line(step >= 1),
        _dot(Icons.store_outlined,       step >= 1),
        _line(step >= 2),
        _dot(Icons.check_circle_outline, step >= 2),
      ],
    );
  }
  Widget _dot(IconData icon, bool active) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: active ? Colors.transparent : const Color(0xFF132D3E),
      border: Border.all(color: active ? _kTeal : Colors.transparent, width: 1.5),
    ),
    child: Icon(icon, color: active ? _kTeal : _kGrey, size: 26),
  );
  Widget _line(bool active) =>
      Container(width: 45, height: 1.2, color: active ? _kTeal : const Color(0xFF132D3E));
}

// ── Text Field ──
class _Field extends StatelessWidget {
  final String label, hint;
  final IconData icon;
  final TextEditingController ctrl;
  final TextInputType? type;
  final String? Function(String?)? validator;
  const _Field({required this.label, required this.hint, required this.icon,
    required this.ctrl, this.type, this.validator});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        TextFormField(
          controller: ctrl, keyboardType: type, validator: validator,
          style: const TextStyle(color: Colors.white, fontSize: 15),
          decoration: InputDecoration(
            hintText: hint, hintStyle: const TextStyle(color: _kGrey, fontSize: 14),
            prefixIcon: Icon(icon, color: _kTeal, size: 22),
            filled: true, fillColor: const Color(0xFF001A2C).withOpacity(0.6),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.05))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: _kTeal, width: 1)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent, width: 1)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent, width: 1)),
          ),
        ),
      ]),
    );
  }
}

// ── Password Field ──
class _PassField extends StatelessWidget {
  final String label, hint;
  final TextEditingController ctrl;
  final bool obscure;
  final VoidCallback onToggle;
  final String? Function(String?)? validator;
  const _PassField({required this.label, required this.hint, required this.ctrl,
    required this.obscure, required this.onToggle, this.validator});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        TextFormField(
          controller: ctrl, obscureText: obscure, validator: validator,
          style: const TextStyle(color: Colors.white, fontSize: 15),
          decoration: InputDecoration(
            hintText: hint, hintStyle: const TextStyle(color: _kGrey, fontSize: 14),
            prefixIcon: const Icon(Icons.lock_outline, color: _kTeal, size: 22),
            suffixIcon: GestureDetector(
              onTap: onToggle,
              child: Icon(obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _kGrey, size: 20),
            ),
            filled: true, fillColor: const Color(0xFF001A2C).withOpacity(0.6),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.05))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: _kTeal, width: 1)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent, width: 1)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Colors.redAccent, width: 1)),
          ),
        ),
      ]),
    );
  }
}

// ── Next Button ──
class _NextBtn extends StatelessWidget {
  final VoidCallback onPressed;
  const _NextBtn({required this.onPressed});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity, height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF009EA3), _kTeal]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: _kTeal.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: const Text('Next', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
      ),
    );
  }
}

// ── Background Painter ──
class _BgPainter extends CustomPainter {
  final double progress;
  _BgPainter(this.progress);
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80);
    p.color = _kTeal.withOpacity(0.2);
    canvas.drawCircle(Offset(size.width * 0.5 + math.sin(progress * 2 * math.pi) * 100,
        size.height * 0.2 + math.cos(progress * 2 * math.pi) * 50), 200, p);
    p.color = const Color(0xFF009EA3).withOpacity(0.15);
    canvas.drawCircle(Offset(size.width * 0.2 + math.cos(progress * 2 * math.pi) * 80,
        size.height * 0.8 + math.sin(progress * 2 * math.pi) * 100), 250, p);
    p.color = const Color(0xFF132D3E).withOpacity(0.4);
    canvas.drawCircle(Offset(size.width * 0.8 + math.sin(progress * 2 * math.pi) * 60,
        size.height * 0.5 + math.cos(progress * 2 * math.pi) * 120), 180, p);
  }
  @override
  bool shouldRepaint(_BgPainter o) => o.progress != progress;
}