import 'package:flutter/material.dart';

class TraderShipmentScheduled extends StatelessWidget {
  final String pickup;
  final String dropoff;
  final String date;
  final String time;
  final String packages;
  final String weight;

  const TraderShipmentScheduled({
    super.key,
    required this.pickup,
    required this.dropoff,
    required this.date,
    required this.time,
    required this.packages,
    required this.weight,
  });

  // generate a simple shipment ID
  String get _shipmentId {
    final now = DateTime.now();
    return 'TM-${now.millisecondsSinceEpoch.toRadixString(36).toUpperCase().substring(0, 8)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color(0xFF1C3449),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 32),

              // ── Check icon ──
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF00BBA7),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00BBA7).withOpacity(0.4),
                      blurRadius: 24,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: const Icon(Icons.check_circle_outline_rounded,
                    color: Colors.white, size: 52),
              ),

              const SizedBox(height: 20),

              const Text(
                'Shipment Scheduled!',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.3),
              ),

              const SizedBox(height: 10),

              Text(
                'Your shipment has been confirmed and\na driver has been assigned',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 13.5,
                    height: 1.6),
              ),

              const SizedBox(height: 28),

              // ── Main card ──
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A1628).withOpacity(0.6),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: const Color(0xFF00D5BE).withOpacity(0.2),
                      width: 0.8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Pickup & Drop-off timeline
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          children: [
                            Container(
                                width: 10,
                                height: 10,
                                decoration: const BoxDecoration(
                                    color: Color(0xFF00D5BE),
                                    shape: BoxShape.circle)),
                            Container(
                                width: 1.5,
                                height: 44,
                                color: const Color(0xFF00D5BE)
                                    .withOpacity(0.3)),
                            Container(
                                width: 10,
                                height: 10,
                                decoration: const BoxDecoration(
                                    color: Color(0xFF0E8FD4),
                                    shape: BoxShape.circle)),
                          ],
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Pickup',
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 11)),
                            Text(pickup,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 8),
                            Text('Drop-off',
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 11)),
                            Text(dropoff,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ],
                    ),

                    Divider(
                        color: const Color(0xFF00D5BE).withOpacity(0.15),
                        height: 28),

                    // Date & Time
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Scheduled Date',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.4),
                                      fontSize: 11)),
                              const SizedBox(height: 4),
                              Row(children: [
                                const Icon(Icons.calendar_month_outlined,
                                    color: Color(0xFF00D5BE), size: 14),
                                const SizedBox(width: 5),
                                Text(date,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500)),
                              ]),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Time',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.4),
                                      fontSize: 11)),
                              const SizedBox(height: 4),
                              Text(time,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // Packages & Weight
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Packages',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.4),
                                      fontSize: 11)),
                              const SizedBox(height: 4),
                              Row(children: [
                                const Icon(Icons.widgets_outlined,
                                    color: Color(0xFF00D5BE), size: 14),
                                const SizedBox(width: 5),
                                Text(packages,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500)),
                              ]),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Weight',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.4),
                                      fontSize: 11)),
                              const SizedBox(height: 4),
                              Text('$weight kg',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                      ],
                    ),

                    Divider(
                        color: const Color(0xFF00D5BE).withOpacity(0.15),
                        height: 28),

                    // Vehicle card
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF00D5BE).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: const Color(0xFF00D5BE).withOpacity(0.2),
                            width: 0.8),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color:
                                  const Color(0xFF00D5BE).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.local_shipping_outlined,
                                color: Color(0xFF00D5BE), size: 20),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Swift Pickup',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600)),
                                Text('Pickup Truck',
                                    style: TextStyle(
                                        color: Color(0xFF00D5BE),
                                        fontSize: 12)),
                              ],
                            ),
                          ),
                          const Text('\$240',
                              style: TextStyle(
                                  color: Color(0xFF00D5BE),
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ── Driver info bar ──
              Container(
                width: double.infinity,
                height: 54,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: const Color(0x1A00D3F2),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: const Color(0xFF00D3F2).withOpacity(0.25),
                      width: 0.8),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          color: Color(0xFF00D3F2), shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'Driver will arrive at pickup in 15 minutes',
                      style:
                          TextStyle(color: Color(0xFF00D3F2), fontSize: 13),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ── Track Shipment button ──
              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF00D5BE), Color(0xFF00D3F2)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFF00D5BE).withOpacity(0.35),
                        blurRadius: 16,
                        offset: const Offset(0, 6)),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/trader_home',
                      (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Track Shipment',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                ),
              ),

              const SizedBox(height: 12),

              // ── Return to Home button ──
              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  color: const Color(0xFF0A1628).withOpacity(0.4),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: Colors.white.withOpacity(0.12), width: 0.8),
                ),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                        context, '/trader_home', (route) => false);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.home_outlined,
                          color: Colors.white.withOpacity(0.7), size: 20),
                      const SizedBox(width: 8),
                      Text('Return to Home',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 15,
                              fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // ── Shipment ID ──
              Column(
                children: [
                  Text('Shipment ID',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 11)),
                  const SizedBox(height: 4),
                  Text(
                    _shipmentId,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 12,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}