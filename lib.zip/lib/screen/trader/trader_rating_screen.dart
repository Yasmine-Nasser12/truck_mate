import 'package:flutter/material.dart';

// ══════════════════════════════════════════════════════
//  TRADER RATING SCREENS
//  trader_rating_screen.dart → lib/screen/trader/
// ══════════════════════════════════════════════════════

const Color _kBg      = Color(0xFF0A1A24);
const Color _kCard    = Color(0xFF0A1628);
const Color _kCard2   = Color(0xFF0F2A3A);
const Color _kTeal    = Color(0xFF00D5BE);
const Color _kGreen   = Color(0xFF009689);
const Color _kMuted   = Color(0xFFCBFBF1);

class RateDriverScreen extends StatefulWidget {
  final String driverName;
  final String driverInitials;
  const RateDriverScreen({
    super.key,
    this.driverName = 'John Driver',
    this.driverInitials = 'JD',
  });

  @override
  State<RateDriverScreen> createState() => _RateDriverScreenState();
}

class _RateDriverScreenState extends State<RateDriverScreen> {
  int _stars = 0;
  bool _recommend = false;
  int _easeOfAccess = 0;
  int _timing = 0;
  int _communication = 0;
  int _facilities = 0;

  final List<String> _starLabels = [
    'Tap a star to rate',
    'Terrible!',
    'Not great...',
    'It was okay.',
    'Pretty good!',
    "Great 5 stars! Can't get any better than that!",
  ];

  bool get _canSubmit =>
      _stars > 0 &&
      _easeOfAccess > 0 &&
      _timing > 0 &&
      _communication > 0 &&
      _facilities > 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              _backBtn(context),
              const Expanded(child: Center(
                child: Text('Reviews and Ratings',
                    style: TextStyle(color: Colors.white, fontSize: 18,
                        fontWeight: FontWeight.bold)))),
              const SizedBox(width: 38),
            ]),
          ),
          const SizedBox(height: 20),
          Expanded(child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(children: [
              _driverCard(),
              const SizedBox(height: 16),
              _card(child: Column(children: [
                const Text('How was the trip?',
                    style: TextStyle(color: Colors.white, fontSize: 16,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (i) => GestureDetector(
                    onTap: () => setState(() => _stars = i + 1),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Icon(
                        i < _stars ? Icons.star_rounded : Icons.star_outline_rounded,
                        color: i < _stars ? _kTeal : _kMuted.withOpacity(0.3),
                        size: 48))))),
                const SizedBox(height: 12),
                Text(_starLabels[_stars],
                    style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 13),
                    textAlign: TextAlign.center),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () => setState(() => _recommend = !_recommend),
                  child: Row(children: [
                    _checkCircle(_recommend),
                    const SizedBox(width: 10),
                    Text('I recommend this driver',
                        style: TextStyle(
                          color: _recommend ? Colors.white : _kMuted.withOpacity(0.4),
                          fontSize: 14)),
                  ])),
              ])),
              const SizedBox(height: 16),
              _card(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('How would you rate the following aspects?',
                      style: TextStyle(color: _kMuted.withOpacity(0.5),
                          fontSize: 14, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 20),
                  _aspectRow('Ease of Access', _easeOfAccess,
                      (v) => setState(() => _easeOfAccess = v)),
                  const SizedBox(height: 20),
                  _aspectRow('Timing', _timing,
                      (v) => setState(() => _timing = v)),
                  const SizedBox(height: 20),
                  _aspectRow('Communication', _communication,
                      (v) => setState(() => _communication = v)),
                  const SizedBox(height: 20),
                  _aspectRow('Facilities', _facilities,
                      (v) => setState(() => _facilities = v)),
                ],
              )),
              const SizedBox(height: 24),
            ]),
          )),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: double.infinity, height: 56,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: _canSubmit
                    ? [_kGreen, const Color(0xFF00B8DB)]
                    : [_kGreen.withOpacity(0.3), const Color(0xFF00B8DB).withOpacity(0.3)],
                  begin: Alignment.centerLeft, end: Alignment.centerRight),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _kGreen.withOpacity(0.2)),
                boxShadow: _canSubmit ? [BoxShadow(
                  color: _kGreen.withOpacity(0.3), blurRadius: 16,
                  offset: const Offset(0, 6))] : [],
              ),
              child: ElevatedButton(
                onPressed: _canSubmit ? () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const WriteReviewScreen())) : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  disabledBackgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                child: Text('Continue',
                    style: TextStyle(
                      color: _canSubmit ? Colors.white : _kMuted.withOpacity(0.3),
                      fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _driverCard() => _card(padding: const EdgeInsets.all(16),
    child: Row(children: [
      Stack(children: [
        Container(width: 64, height: 64,
          decoration: BoxDecoration(shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFFFF8904), Color(0xFF9810FA)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            border: Border.all(color: _kGreen, width: 2)),
          child: Center(child: Text(widget.driverInitials,
              style: const TextStyle(color: Colors.white, fontSize: 20,
                  fontWeight: FontWeight.bold)))),
        Positioned(bottom: 2, right: 2,
          child: Container(width: 14, height: 14,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: _kTeal,
              border: Border.all(color: _kBg, width: 2)))),
      ]),
      const SizedBox(width: 14),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.driverName,
            style: const TextStyle(color: Colors.white, fontSize: 16,
                fontWeight: FontWeight.bold)),
        Text('Professional Driver',
            style: TextStyle(color: _kMuted.withOpacity(0.35), fontSize: 13)),
      ]),
    ]));

  Widget _aspectRow(String label, int selected, ValueChanged<int> onSelect) {
    final labels = ['Bad', 'So so', 'Good', 'Great', 'Amazing'];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Colors.white, fontSize: 14,
          fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(5, (i) {
          final active = selected == i + 1;
          return GestureDetector(
            onTap: () => onSelect(i + 1),
            child: Column(children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 48, height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: active ? const LinearGradient(
                    colors: [_kGreen, Color(0xFF00B8DB)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
                  color: active ? null : Colors.transparent,
                  border: Border.all(
                    color: active ? Colors.transparent : _kGreen.withOpacity(0.4),
                    width: 1.5)),
                child: Center(child: Text('${i + 1}',
                    style: TextStyle(
                      color: active ? Colors.white : _kMuted.withOpacity(0.35),
                      fontSize: 15, fontWeight: FontWeight.w600)))),
              const SizedBox(height: 4),
              Text(labels[i],
                  style: TextStyle(color: _kMuted.withOpacity(0.35), fontSize: 10)),
            ]));
        })),
    ]);
  }

  Widget _checkCircle(bool active) => AnimatedContainer(
    duration: const Duration(milliseconds: 200),
    width: 24, height: 24,
    decoration: BoxDecoration(shape: BoxShape.circle,
      gradient: active ? const LinearGradient(
        colors: [_kGreen, Color(0xFF00B8DB)],
        begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
      border: Border.all(
        color: active ? Colors.transparent : _kMuted.withOpacity(0.3),
        width: 1.5)),
    child: active ? const Icon(Icons.check, color: Colors.white, size: 14) : null);
}

class WriteReviewScreen extends StatefulWidget {
  const WriteReviewScreen({super.key});
  @override
  State<WriteReviewScreen> createState() => _WriteReviewScreenState();
}

class _WriteReviewScreenState extends State<WriteReviewScreen> {
  final _summaryCtrl = TextEditingController();
  final _reviewCtrl  = TextEditingController();
  @override void dispose() { _summaryCtrl.dispose(); _reviewCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Row(children: [
            _backBtn(context),
            const Expanded(child: Center(child: Text('Write Review',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)))),
            const SizedBox(width: 38),
          ])),
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
            decoration: BoxDecoration(color: _kCard.withOpacity(0.6),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kTeal.withOpacity(0.2), width: 0.8)),
            child: Column(children: [
              _card2(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Summarize your review', style: TextStyle(color: Colors.white,
                    fontSize: 15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                TextField(controller: _summaryCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Great experience!',
                    hintStyle: TextStyle(color: _kMuted.withOpacity(0.3), fontSize: 14),
                    filled: true, fillColor: _kCard.withOpacity(0.5),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none))),
              ])),
              const SizedBox(height: 16),
              _card2(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Write your review', style: TextStyle(color: Colors.white,
                    fontSize: 15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                TextField(controller: _reviewCtrl, maxLines: 5,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Share details about your experience...',
                    hintStyle: TextStyle(color: _kMuted.withOpacity(0.3), fontSize: 14),
                    filled: true, fillColor: _kCard.withOpacity(0.5),
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none))),
              ])),
              const SizedBox(height: 16),
              _card2(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Upload Photos', style: TextStyle(color: Colors.white,
                    fontSize: 15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Text('Share photos from the trip (optional)',
                    style: TextStyle(color: _kMuted.withOpacity(0.3), fontSize: 13)),
                const SizedBox(height: 14),
                Container(width: 60, height: 60,
                  decoration: BoxDecoration(color: _kCard.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _kGreen.withOpacity(0.3), width: 0.8)),
                  child: const Icon(Icons.add_photo_alternate_outlined, color: _kGreen, size: 26)),
              ])),
              const SizedBox(height: 24),
              Container(width: double.infinity, height: 56,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_kGreen, Color(0xFF00B8DB)],
                    begin: Alignment.centerLeft, end: Alignment.centerRight),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: _kGreen.withOpacity(0.3),
                    blurRadius: 16, offset: const Offset(0, 6))]),
                child: ElevatedButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ReviewSubmittedScreen())),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  child: const Text('Submit Review', style: TextStyle(color: Colors.white,
                      fontSize: 16, fontWeight: FontWeight.bold)))),
              const SizedBox(height: 24),
            ]),
          ),
        )),
      ])),
    );
  }
}

class ReviewSubmittedScreen extends StatelessWidget {
  const ReviewSubmittedScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Row(children: [_backBtn(context)])),
        const SizedBox(height: 24),
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(width: double.infinity,
            decoration: BoxDecoration(color: _kCard.withOpacity(0.6),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _kTeal.withOpacity(0.2), width: 0.8)),
            child: Column(children: [
              const SizedBox(height: 48),
              Container(width: 120, height: 120,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [_kGreen, Color(0xFF00B8DB)],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter),
                  boxShadow: [BoxShadow(color: _kGreen.withOpacity(0.4),
                    blurRadius: 30, spreadRadius: 4)]),
                child: const Icon(Icons.check, color: Colors.white, size: 52)),
              const SizedBox(height: 40),
              Divider(color: _kTeal.withOpacity(0.15), height: 1),
              Padding(padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
                child: Column(children: [
                  const Text('Thank you for your\nreview!',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 26,
                          fontWeight: FontWeight.bold, height: 1.3)),
                  const SizedBox(height: 16),
                  Text('You help fellow traders in\ndiscovering the best drivers.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _kMuted.withOpacity(0.5), fontSize: 15, height: 1.6)),
                ])),
              Divider(color: _kTeal.withOpacity(0.15), height: 1),
              const SizedBox(height: 40),
              SizedBox(width: 180, height: 160,
                child: Stack(alignment: Alignment.center, children: [
                  Positioned(left: 0, top: 20,
                    child: Transform.rotate(angle: -0.15, child: _miniCard(0.4))),
                  Positioned(right: 0, top: 20,
                    child: Transform.rotate(angle: 0.15, child: _miniCard(0.4))),
                  _miniCard(1.0),
                ])),
              const SizedBox(height: 40),
            ]),
          ),
        )),
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Container(width: double.infinity, height: 56,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_kTeal, Color(0xFF00B8DB)],
                begin: Alignment.centerLeft, end: Alignment.centerRight),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: _kTeal.withOpacity(0.35),
                blurRadius: 16, offset: const Offset(0, 6))]),
            child: ElevatedButton(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ReviewsListScreen())),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: const Text('View All Reviews', style: TextStyle(color: Colors.white,
                  fontSize: 16, fontWeight: FontWeight.bold))))),
      ])),
    );
  }

  Widget _miniCard(double opacity) => Opacity(opacity: opacity,
    child: Container(width: 110, height: 130,
      decoration: BoxDecoration(color: _kCard2, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kTeal.withOpacity(0.2), width: 0.8)),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: List.generate(5, (i) => Padding(
          padding: const EdgeInsets.only(right: 4),
          child: Container(width: 10, height: 10,
            decoration: const BoxDecoration(shape: BoxShape.circle, color: _kGreen))))),
        const SizedBox(height: 12),
        Container(width: double.infinity, height: 6,
          decoration: BoxDecoration(color: _kGreen.withOpacity(0.5),
              borderRadius: BorderRadius.circular(3))),
        const SizedBox(height: 6),
        Container(width: 70, height: 6,
          decoration: BoxDecoration(color: _kGreen.withOpacity(0.3),
              borderRadius: BorderRadius.circular(3))),
        const SizedBox(height: 6),
        Container(width: 50, height: 6,
          decoration: BoxDecoration(color: _kGreen.withOpacity(0.2),
              borderRadius: BorderRadius.circular(3))),
      ])));
}

class ReviewsListScreen extends StatelessWidget {
  const ReviewsListScreen({super.key});

  static const _reviews = [
    (time: 'Just now', title: 'Excellent service',
     body: 'Very professional driver. Delivered everything on time and in perfect condition.',
     stars: 5, hasPhotos: true, isNew: true),
    (time: '5 days ago', title: 'Good communication',
     body: 'Driver kept me updated throughout the journey. Everything arrived safely.',
     stars: 4, hasPhotos: false, isNew: false),
    (time: '1 week ago', title: 'Outstanding!',
     body: 'Best driver I have worked with. Very careful with the cargo.',
     stars: 5, hasPhotos: true, isNew: false),
    (time: '1 week ago', title: 'Highly professional',
     body: 'Smooth experience from start to finish. Would definitely work with this driver again.',
     stars: 5, hasPhotos: false, isNew: false),
    (time: '2 weeks ago', title: 'Reliable and punctual',
     body: 'Great timing and very easy to communicate with.',
     stars: 4, hasPhotos: false, isNew: false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Row(children: [
            _backBtn(context),
            const SizedBox(width: 14),
            const Text('Reviews & Ratings', style: TextStyle(color: Colors.white,
                fontSize: 18, fontWeight: FontWeight.bold)),
          ])),
        const SizedBox(height: 20),
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(children: [
            Container(padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: _kCard2,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _kTeal.withOpacity(0.15), width: 0.8)),
              child: Column(children: [
                Row(children: [
                  Container(width: 64, height: 64,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [Color(0xFFFF8904), Color(0xFF9810FA)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                      border: Border.all(color: _kTeal, width: 2)),
                    child: const Center(child: Text('JD',
                        style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)))),
                  const SizedBox(width: 16),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('John Michael', style: TextStyle(color: Colors.white,
                        fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Professional Driver',
                        style: TextStyle(color: _kMuted.withOpacity(0.4), fontSize: 13)),
                  ]),
                ]),
                const SizedBox(height: 16),
                Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(color: _kCard.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(14)),
                  child: Row(children: [
                    const Icon(Icons.star_rounded, color: _kTeal, size: 24),
                    const SizedBox(width: 8),
                    const Text('4.7', style: TextStyle(color: Colors.white,
                        fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 12),
                    Container(width: 1, height: 20, color: _kTeal.withOpacity(0.3)),
                    const SizedBox(width: 12),
                    Text('128 reviews',
                        style: TextStyle(color: _kMuted.withOpacity(0.4), fontSize: 14)),
                  ])),
              ])),
            const SizedBox(height: 20),
            ..._reviews.map((r) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _reviewTile(r.time, r.title, r.body, r.stars, r.hasPhotos, r.isNew))),
            const SizedBox(height: 24),
            Container(width: double.infinity, height: 56,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_kTeal, Color(0xFF00B8DB)],
                  begin: Alignment.centerLeft, end: Alignment.centerRight),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: _kTeal.withOpacity(0.35),
                  blurRadius: 16, offset: const Offset(0, 6))]),
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                child: const Text('Back to Shipment', style: TextStyle(color: Colors.white,
                    fontSize: 16, fontWeight: FontWeight.bold)))),
            const SizedBox(height: 24),
          ]),
        )),
      ])),
    );
  }

  Widget _reviewTile(String time, String title, String body,
      int stars, bool hasPhotos, bool isNew) {
    return Container(padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [_kCard2, Color(0xFF0A1F2F)],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kTeal.withOpacity(0.1), width: 0.8)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 40, height: 40,
            decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF1C3449)),
            child: Center(child: Text('T',
                style: TextStyle(color: _kMuted.withOpacity(0.6), fontSize: 16,
                    fontWeight: FontWeight.bold)))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Trader', style: TextStyle(color: Colors.white, fontSize: 14,
                fontWeight: FontWeight.w600)),
            Text(time, style: TextStyle(color: _kMuted.withOpacity(0.4), fontSize: 12)),
          ])),
          if (isNew)
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: _kTeal, borderRadius: BorderRadius.circular(20)),
              child: const Text('New', style: TextStyle(color: Colors.white, fontSize: 11,
                  fontWeight: FontWeight.bold)))
          else
            Row(children: List.generate(5, (i) => Icon(
              i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
              color: i < stars ? _kTeal : _kMuted.withOpacity(0.3),
              size: 18))),
        ]),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 15,
            fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(body, style: TextStyle(color: _kMuted.withOpacity(0.5), fontSize: 13, height: 1.5)),
        if (hasPhotos) ...[
          const SizedBox(height: 10),
          const Row(children: [
            Icon(Icons.camera_alt_outlined, color: _kTeal, size: 16),
            SizedBox(width: 6),
            Text('Photos attached', style: TextStyle(color: _kTeal, fontSize: 13)),
          ]),
        ],
      ]));
  }
}

Widget _backBtn(BuildContext context) => GestureDetector(
  onTap: () => Navigator.pop(context),
  child: Container(width: 38, height: 38,
    decoration: BoxDecoration(color: _kCard.withOpacity(0.7),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: _kTeal.withOpacity(0.2), width: 0.8)),
    child: const Icon(Icons.arrow_back, color: _kGreen, size: 18)));

Widget _card({required Widget child, EdgeInsetsGeometry? padding}) =>
  Container(width: double.infinity,
    padding: padding ?? const EdgeInsets.all(20),
    decoration: BoxDecoration(color: _kCard.withOpacity(0.7),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _kTeal.withOpacity(0.15), width: 0.8)),
    child: child);

Widget _card2({required Widget child}) =>
  Container(width: double.infinity, padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(color: _kCard2, borderRadius: BorderRadius.circular(24),
      border: Border.all(color: _kTeal.withOpacity(0.15), width: 0.8)),
    child: child);